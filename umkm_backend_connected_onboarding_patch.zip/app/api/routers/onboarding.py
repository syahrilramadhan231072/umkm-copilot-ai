"""
Onboarding API Router
=====================

Endpoint minimal untuk menghubungkan onboarding frontend dengan backend.

Layering:
Frontend -> FastAPI Router -> Service/Repository -> Supabase

Catatan:
- Router ini tidak mengubah database schema.
- Router ini memakai service/repository yang sudah tersedia.
- Helper adapter dibuat agar tetap kompatibel dengan beberapa kemungkinan nama
  method pada service/repository yang sudah ada.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.api.response import success_response
from app.database.connection import get_supabase_client
from app.repositories.business_repository import BusinessRepository
from app.repositories.product_repository import ProductRepository
from app.services.business_service import BusinessService
from app.services.product_service import ProductService


router = APIRouter(prefix="/api/v1/onboarding", tags=["onboarding"])


class BusinessProfileCreateRequest(BaseModel):
    """Request pembuatan profil bisnis."""

    business_name: str = Field(..., min_length=1, max_length=255)
    owner_name: str = Field(..., min_length=1, max_length=255)
    business_type: str = Field(..., min_length=1, max_length=255)
    currency: str = Field(default="IDR", min_length=3, max_length=10)
    timezone: str = Field(default="Asia/Jakarta", min_length=1, max_length=100)
    language: str = Field(default="Bahasa Indonesia", min_length=1, max_length=100)


class BusinessProfileCreateResponse(BaseModel):
    """Response pembuatan profil bisnis."""

    business_id: str
    business_name: str
    owner_name: str
    business_type: str
    currency: str
    timezone: str
    language: str


class ProductCreateRequest(BaseModel):
    """Request pembuatan produk."""

    business_id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1, max_length=255)
    selling_price: float = Field(..., ge=0)
    cost_price: float = Field(default=0, ge=0)
    initial_stock: int = Field(default=0, ge=0)
    unit: str = Field(default="pcs", min_length=1, max_length=50)
    category: str = Field(default="Umum", min_length=1, max_length=100)
    sku: str | None = Field(default=None, max_length=100)
    barcode: str | None = Field(default=None, max_length=100)


class ProductCreateResponse(BaseModel):
    """Response pembuatan produk."""

    product_id: str
    business_id: str
    name: str
    selling_price: float
    cost_price: float
    stock: int
    unit: str
    category: str


class ProductListResponse(BaseModel):
    """Response daftar produk."""

    products: list[dict[str, Any]]


@router.post("/business-profile")
async def create_business_profile(
    request: BusinessProfileCreateRequest,
) -> dict[str, Any]:
    """
    Buat profil bisnis dan kembalikan business_id.

    Frontend tidak perlu membuat UUID sendiri.
    """

    service = _build_business_service()
    payload = _business_payload(request)

    try:
        created = await _maybe_await(
            _call_first_available(
                service,
                method_names=(
                    "create_business_profile",
                    "create_profile",
                    "create_business",
                    "create",
                ),
                payload=payload,
            )
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Profil bisnis belum dapat dibuat: {exc}",
        ) from exc

    normalized = _normalize_business_response(created, fallback_payload=payload)

    return success_response(
        data=BusinessProfileCreateResponse(**normalized).model_dump(),
        message="Profil bisnis berhasil dibuat.",
    )


@router.post("/products")
async def create_product(request: ProductCreateRequest) -> dict[str, Any]:
    """
    Buat produk untuk business_id yang sudah dibuat backend.
    """

    _validate_uuid(request.business_id, "business_id")

    service = _build_product_service()
    payload = _product_payload(request)

    try:
        created = await _maybe_await(
            _call_first_available(
                service,
                method_names=(
                    "create_product",
                    "create",
                    "add_product",
                ),
                payload=payload,
            )
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Produk belum dapat dibuat: {exc}",
        ) from exc

    normalized = _normalize_product_response(created, fallback_payload=payload)

    return success_response(
        data=ProductCreateResponse(**normalized).model_dump(),
        message="Produk berhasil dibuat.",
    )


@router.get("/products/{business_id}")
async def list_products(business_id: str, limit: int = 100) -> dict[str, Any]:
    """
    Ambil daftar produk untuk business_id.
    """

    _validate_uuid(business_id, "business_id")

    service = _build_product_service()

    try:
        products = await _maybe_await(
            _call_first_available(
                service,
                method_names=(
                    "list_active",
                    "list_by_business",
                    "list_products",
                    "list",
                ),
                payload={"business_id": business_id, "limit": limit},
            )
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Produk belum dapat dimuat: {exc}",
        ) from exc

    return success_response(
        data=ProductListResponse(products=_normalize_product_list(products)).model_dump(),
        message="Produk berhasil dimuat.",
    )


def _build_business_service() -> BusinessService:
    """Bangun BusinessService dengan repository."""

    client = get_supabase_client()
    repository = BusinessRepository(client)

    try:
        return BusinessService(repository)
    except TypeError:
        return BusinessService(business_repository=repository)


def _build_product_service() -> ProductService:
    """Bangun ProductService dengan repository."""

    client = get_supabase_client()
    repository = ProductRepository(client)

    try:
        return ProductService(repository)
    except TypeError:
        return ProductService(product_repository=repository)


def _business_payload(request: BusinessProfileCreateRequest) -> dict[str, Any]:
    """Bangun payload bisnis."""

    return {
        "business_name": request.business_name.strip(),
        "owner_name": request.owner_name.strip(),
        "business_type": request.business_type.strip(),
        "currency": request.currency.strip(),
        "timezone": request.timezone.strip(),
        "language": request.language.strip(),
    }


def _product_payload(request: ProductCreateRequest) -> dict[str, Any]:
    """Bangun payload produk."""

    return {
        "business_id": request.business_id.strip(),
        "name": request.name.strip(),
        "selling_price": float(request.selling_price),
        "cost_price": float(request.cost_price),
        "stock": int(request.initial_stock),
        "initial_stock": int(request.initial_stock),
        "unit": request.unit.strip(),
        "category": request.category.strip(),
        "sku": request.sku.strip() if request.sku else None,
        "barcode": request.barcode.strip() if request.barcode else None,
        "is_active": True,
    }


def _call_first_available(
    target: Any,
    *,
    method_names: tuple[str, ...],
    payload: dict[str, Any],
) -> Any:
    """
    Panggil method pertama yang tersedia pada service/repository.

    Method service di project mungkin bernama `create`, `create_product`,
    atau `create_business_profile`. Helper ini menjaga patch tetap adaptif.
    """

    for method_name in method_names:
        method = getattr(target, method_name, None)
        if callable(method):
            return _call_method(method, payload)

    raise AttributeError(
        f"Tidak ada method yang tersedia: {', '.join(method_names)}"
    )


def _call_method(method: Any, payload: dict[str, Any]) -> Any:
    """Panggil method dengan signature yang umum dipakai."""

    try:
        return method(payload)
    except TypeError:
        pass

    try:
        return method(**payload)
    except TypeError:
        pass

    business_id = payload.get("business_id")
    if business_id:
        data = dict(payload)
        data.pop("business_id", None)
        try:
            return method(business_id, data)
        except TypeError:
            pass

    raise TypeError("Signature method service/repository tidak dikenali.")


async def _maybe_await(value: Any) -> Any:
    """Await jika value adalah awaitable."""

    if hasattr(value, "__await__"):
        return await value

    return value


def _normalize_business_response(
    created: Any,
    *,
    fallback_payload: dict[str, Any],
) -> dict[str, Any]:
    """Normalisasi response business."""

    data = _to_mapping(created)

    business_id = (
        data.get("business_id")
        or data.get("id")
        or data.get("uuid")
    )

    if not business_id:
        raise ValueError("Backend tidak mengembalikan business_id.")

    return {
        "business_id": str(business_id),
        "business_name": str(data.get("business_name") or fallback_payload["business_name"]),
        "owner_name": str(data.get("owner_name") or fallback_payload["owner_name"]),
        "business_type": str(data.get("business_type") or fallback_payload["business_type"]),
        "currency": str(data.get("currency") or fallback_payload["currency"]),
        "timezone": str(data.get("timezone") or fallback_payload["timezone"]),
        "language": str(data.get("language") or fallback_payload["language"]),
    }


def _normalize_product_response(
    created: Any,
    *,
    fallback_payload: dict[str, Any],
) -> dict[str, Any]:
    """Normalisasi response product."""

    data = _to_mapping(created)

    product_id = (
        data.get("product_id")
        or data.get("id")
        or data.get("uuid")
    )

    if not product_id:
        raise ValueError("Backend tidak mengembalikan product_id.")

    return {
        "product_id": str(product_id),
        "business_id": str(data.get("business_id") or fallback_payload["business_id"]),
        "name": str(data.get("name") or data.get("product_name") or fallback_payload["name"]),
        "selling_price": float(data.get("selling_price") or fallback_payload["selling_price"]),
        "cost_price": float(data.get("cost_price") or fallback_payload["cost_price"]),
        "stock": int(data.get("stock") or data.get("current_stock") or fallback_payload["stock"]),
        "unit": str(data.get("unit") or fallback_payload["unit"]),
        "category": str(data.get("category") or fallback_payload["category"]),
    }


def _normalize_product_list(products: Any) -> list[dict[str, Any]]:
    """Normalisasi daftar produk."""

    if isinstance(products, dict):
        if isinstance(products.get("data"), list):
            raw_items = products["data"]
        elif isinstance(products.get("products"), list):
            raw_items = products["products"]
        else:
            raw_items = [products]
    elif isinstance(products, list):
        raw_items = products
    else:
        raw_items = []

    result: list[dict[str, Any]] = []
    for item in raw_items:
        mapping = _to_mapping(item)
        if mapping:
            result.append(mapping)

    return result


def _to_mapping(value: Any) -> dict[str, Any]:
    """Konversi object/dict/model menjadi dict."""

    if value is None:
        return {}

    if isinstance(value, dict):
        return dict(value)

    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return dict(model_dump())

    dict_method = getattr(value, "dict", None)
    if callable(dict_method):
        return dict(dict_method())

    data = getattr(value, "data", None)
    if isinstance(data, dict):
        return dict(data)

    if hasattr(value, "__dict__"):
        return dict(value.__dict__)

    return {}


def _validate_uuid(value: str, field_name: str) -> None:
    """Validasi UUID."""

    try:
        UUID(value)
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail=f"{field_name} tidak valid.",
        ) from exc
