"""
Beranda UMKM Copilot AI
=======================

Halaman awal dengan onboarding wizard berbahasa Indonesia.
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    ensure_frontend_session,
    get_api_client_from_session_state,
)
from app.frontend.ui_components import render_api_error, render_hero, render_progress_indicator


def render_app() -> None:
    """Render halaman beranda."""

    st = _get_streamlit()
    st.set_page_config(
        page_title="UMKM Copilot AI",
        page_icon="🤖",
        layout="wide",
    )
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    local_business_saved = bool(st.session_state.get("business_name"))
    client = get_api_client_from_session_state(st.session_state)

    dashboard_response: dict[str, Any] | None = None
    if is_valid_uuid(business_id):
        with st.spinner("Memeriksa kesiapan bisnis..."):
            dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
        local_business_saved=local_business_saved,
    )

    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Selamat datang",
        title="UMKM Copilot AI",
        description="Mari siapkan ruang kerja bisnis Anda langkah demi langkah.",
    )

    render_progress_indicator(st, state)

    st.divider()

    if state.dashboard_ready:
        st.success("Ruang kerja bisnis sudah siap. Anda dapat membuka Dashboard.")
        if st.button("Buka Dashboard", type="primary"):
            switch_page(st, "pages/Dashboard.py")
        return

    if state.next_step == "business_profile":
        st.markdown("### Mulai dari profil bisnis")
        st.caption("Isi informasi dasar bisnis agar aplikasi dapat menyiapkan pengalaman yang sesuai.")
        if st.button("Mulai Penyiapan", type="primary"):
            switch_page(st, "pages/Business_Profile.py")
        if state.error_message and local_business_saved:
            st.warning(
                "Preferensi bisnis sudah tersimpan di perangkat ini, tetapi ruang kerja belum terhubung ke backend."
            )
        return

    if state.next_step == "connect_backend":
        st.markdown("### Hubungkan ruang kerja")
        render_api_error(st, state.error_message or "Ruang kerja belum dapat dimuat.")
        if st.button("Buka Pengaturan", type="primary"):
            switch_page(st, "pages/Settings.py")
        return

    if state.next_step == "products":
        st.markdown("### Tambahkan produk")
        st.caption("Produk diperlukan sebelum transaksi dan analisis bisnis dapat berjalan.")
        if st.button("Lanjut ke Produk", type="primary"):
            switch_page(st, "pages/Products.py")
        return

    if state.next_step == "first_transaction":
        st.markdown("### Catat transaksi pertama")
        st.caption("Transaksi pertama akan membuka pengalaman dashboard dan asisten bisnis.")
        if st.button("Catat Transaksi Pertama", type="primary"):
            switch_page(st, "pages/First_Transaction.py")


def _get_streamlit() -> Any:
    """Import Streamlit secara lazy."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_app()
