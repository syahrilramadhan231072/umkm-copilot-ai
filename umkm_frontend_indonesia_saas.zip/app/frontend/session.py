"""
Session Frontend
================

Helper session state untuk Streamlit.
"""

from __future__ import annotations

from typing import Any, MutableMapping

from app.frontend.api_client import FrontendApiClient


DEFAULT_API_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_BUSINESS_ID = ""
DEFAULT_SESSION_ID = "sesi-utama"
DEFAULT_LIMIT = 1000
DEFAULT_CURRENCY = "IDR"
DEFAULT_TIMEZONE = "Asia/Jakarta"
DEFAULT_LANGUAGE = "Bahasa Indonesia"


def ensure_frontend_session(session_state: MutableMapping[str, Any]) -> None:
    """Pastikan semua kunci session tersedia."""

    session_state.setdefault("api_base_url", DEFAULT_API_BASE_URL)
    session_state.setdefault("business_id", DEFAULT_BUSINESS_ID)
    session_state.setdefault("session_id", DEFAULT_SESSION_ID)
    session_state.setdefault("dashboard_limit", DEFAULT_LIMIT)
    session_state.setdefault("business_name", "")
    session_state.setdefault("owner_name", "")
    session_state.setdefault("business_type", "")
    session_state.setdefault("currency", DEFAULT_CURRENCY)
    session_state.setdefault("timezone", DEFAULT_TIMEZONE)
    session_state.setdefault("language", DEFAULT_LANGUAGE)
    session_state.setdefault("workspace_connected", False)


def get_api_client_from_session_state(
    session_state: MutableMapping[str, Any],
) -> FrontendApiClient:
    """Bangun API client dari session state."""

    ensure_frontend_session(session_state)

    return FrontendApiClient(api_base_url=str(session_state["api_base_url"]))


def get_business_id(session_state: MutableMapping[str, Any]) -> str:
    """Ambil kode ruang kerja aktif."""

    ensure_frontend_session(session_state)

    return str(session_state["business_id"])


def get_session_id(session_state: MutableMapping[str, Any]) -> str:
    """Ambil kode sesi aktif."""

    ensure_frontend_session(session_state)

    return str(session_state["session_id"])


def build_common_payload(
    session_state: MutableMapping[str, Any],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Bangun payload umum."""

    ensure_frontend_session(session_state)

    payload = {
        "business_id": str(session_state["business_id"]),
        "session_id": str(session_state["session_id"]),
    }

    if extra:
        payload.update(extra)

    return payload
