"""
Komponen UI Frontend
====================

Komponen visual reusable untuk Streamlit.
"""

from __future__ import annotations

from typing import Any

from app.frontend.onboarding import OnboardingState, get_current_step_number
from app.frontend.navigation import switch_page


def render_hero(
    st: Any,
    *,
    eyebrow: str,
    title: str,
    description: str,
) -> None:
    """Render hero section."""

    st.markdown(
        f"""
        <section class="umkm-page-hero">
          <p class="umkm-page-hero__eyebrow">{eyebrow}</p>
          <h1 class="umkm-page-hero__title">{title}</h1>
          <p class="umkm-page-hero__description">{description}</p>
        </section>
        """,
        unsafe_allow_html=True,
    )


def render_progress_indicator(st: Any, state: OnboardingState) -> None:
    """Render indikator progres sederhana."""

    current_step = get_current_step_number(state)
    progress = min(max(state.completion_percent, 0), 100)

    st.progress(progress, text=f"Langkah {current_step} dari 4")

    labels = ["Profil Bisnis", "Produk", "Transaksi Pertama", "Dashboard"]
    columns = st.columns(4)

    for index, label in enumerate(labels, start=1):
        with columns[index - 1]:
            if index < current_step:
                st.success(f"✓ {label}")
            elif index == current_step:
                st.info(f"• {label}")
            else:
                st.caption(label)


def render_locked_page(
    st: Any,
    *,
    message: str,
    state: OnboardingState,
    next_action_label: str,
    next_page: str,
) -> None:
    """Render halaman terkunci dengan arahan sederhana."""

    st.warning(message)
    render_progress_indicator(st, state)

    if st.button(next_action_label, type="primary"):
        switch_page(st, next_page)


def render_api_error(st: Any, message: str) -> None:
    """Render pesan error API yang ramah pengguna."""

    st.error(message)
    st.caption("Pastikan koneksi backend aktif. Pengaturan teknis tersedia pada bagian Lanjutan.")


def render_empty_state(
    st: Any,
    *,
    title: str,
    description: str,
    action_label: str | None = None,
    action_page: str | None = None,
) -> None:
    """Render empty state."""

    st.markdown(f"### {title}")
    st.caption(description)

    if action_label and action_page:
        if st.button(action_label, type="primary"):
            switch_page(st, action_page)
