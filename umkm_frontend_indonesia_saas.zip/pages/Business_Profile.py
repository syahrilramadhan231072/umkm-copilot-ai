"""
Profil Bisnis
=============
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_hero, render_progress_indicator


PAGE_NAME = "settings"


def render_page() -> None:
    """Render halaman profil bisnis."""

    st = _get_streamlit()
    st.set_page_config(page_title="Profil Bisnis", page_icon="🏪", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    local_business_saved = bool(st.session_state.get("business_name"))
    dashboard_response: dict[str, Any] | None = None

    if is_valid_uuid(business_id):
        client = get_api_client_from_session_state(st.session_state)
        dashboard_response = client.get_dashboard(
            business_id=business_id,
            limit=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)),
        )

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
        local_business_saved=local_business_saved,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 1",
        title="Profil Bisnis",
        description="Lengkapi informasi dasar agar aplikasi memahami konteks bisnis Anda.",
    )
    render_progress_indicator(st, state)

    with st.form("business_profile_form"):
        business_name = st.text_input("Nama Bisnis", value=str(st.session_state.get("business_name", "")))
        owner_name = st.text_input("Nama Pemilik", value=str(st.session_state.get("owner_name", "")))
        business_type = st.text_input("Jenis Bisnis", value=str(st.session_state.get("business_type", "")))
        currency = st.selectbox(
            "Mata Uang",
            ["IDR", "USD"],
            index=0 if st.session_state.get("currency", "IDR") == "IDR" else 1,
        )
        timezone = st.selectbox(
            "Zona Waktu",
            ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"],
        )
        submitted = st.form_submit_button("Simpan Profil Bisnis", type="primary")

    if submitted:
        st.session_state["business_name"] = business_name.strip()
        st.session_state["owner_name"] = owner_name.strip()
        st.session_state["business_type"] = business_type.strip()
        st.session_state["currency"] = currency
        st.session_state["timezone"] = timezone

        if is_valid_uuid(str(st.session_state.get("business_id", ""))):
            st.success("Profil bisnis tersimpan dan ruang kerja sudah terhubung.")
            if st.button("Lanjut ke Produk"):
                switch_page(st, "pages/Products.py")
        else:
            st.warning(
                "Preferensi bisnis tersimpan, tetapi ruang kerja bisnis belum terhubung ke backend."
            )
            st.caption(
                "Saat ini backend belum menyediakan endpoint pembuatan ruang kerja baru. "
                "Admin dapat menghubungkan ruang kerja melalui Pengaturan > Lanjutan."
            )

    with st.expander("Lanjutan"):
        st.caption(
            "Bagian ini untuk admin atau pengembang. Pengguna biasa tidak perlu mengubahnya."
        )
        workspace_code = st.text_input(
            "Kode Ruang Kerja",
            value=str(st.session_state.get("business_id", "")),
            type="password",
        )
        if st.button("Hubungkan Ruang Kerja"):
            st.session_state["business_id"] = workspace_code.strip()
            if is_valid_uuid(workspace_code):
                st.success("Ruang kerja berhasil disimpan.")
            else:
                st.error("Kode ruang kerja belum valid.")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
