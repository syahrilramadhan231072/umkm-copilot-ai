"""
Transaksi Pertama
=================
"""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_hero, render_locked_page, render_progress_indicator


PAGE_NAME = "transactions"


def render_page() -> None:
    """Render halaman transaksi pertama."""

    st = _get_streamlit()
    st.set_page_config(page_title="Transaksi Pertama", page_icon="🧾", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "sesi-utama"))
    dashboard_response = None

    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(
            business_id=business_id,
            limit=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)),
        )

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
        local_business_saved=bool(st.session_state.get("business_name")),
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 3",
        title="Transaksi Pertama",
        description="Catat penjualan pertama agar dashboard dan asisten bisnis memiliki konteks nyata.",
    )
    render_progress_indicator(st, state)

    if not state.business_id_valid:
        render_locked_page(
            st,
            message="Ruang kerja belum terhubung.",
            state=state,
            next_action_label="Buka Profil Bisnis",
            next_page="pages/Business_Profile.py",
        )
        return

    if not state.has_products:
        render_locked_page(
            st,
            message="Produk belum tersedia. Tambahkan atau hubungkan produk terlebih dahulu.",
            state=state,
            next_action_label="Buka Produk",
            next_page="pages/Products.py",
        )
        return

    with st.form("first_transaction_form"):
        product_id = st.text_input(
            "Kode Produk",
            type="password",
            help="Kode ini disediakan oleh backend/admin. Pengguna biasa tidak perlu melihat detail teknisnya.",
        )
        quantity = st.number_input("Jumlah Terjual", min_value=1, value=1, step=1)
        payment_method = st.selectbox(
            "Metode Pembayaran",
            ["cash", "qris", "transfer", "credit_card", "other"],
            format_func=_payment_label,
        )
        notes = st.text_area("Catatan", value="Transaksi pertama")
        submitted = st.form_submit_button("Catat Transaksi", type="primary")

    if submitted:
        payload = {
            "business_id": business_id,
            "product_id": product_id.strip(),
            "quantity": int(quantity),
            "payment_method": str(payment_method),
            "status": "completed",
            "notes": notes,
            "session_id": session_id,
        }
        response = client.record_transaction(payload)

        if response.get("success"):
            st.success("Transaksi pertama berhasil dicatat.")
            if st.button("Buka Dashboard"):
                switch_page(st, "pages/Dashboard.py")
        else:
            st.error(_error_message(response))


def _payment_label(value: str) -> str:
    """Ubah label metode pembayaran."""

    labels = {
        "cash": "Tunai",
        "qris": "QRIS",
        "transfer": "Transfer",
        "credit_card": "Kartu Kredit",
        "other": "Lainnya",
    }

    return labels.get(value, value)


def _error_message(response: Mapping[str, Any]) -> str:
    """Ambil pesan error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])

    return "Transaksi belum berhasil dicatat."


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
