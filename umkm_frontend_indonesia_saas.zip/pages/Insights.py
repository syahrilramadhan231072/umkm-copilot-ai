"""
Rekomendasi
===========
"""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_hero, render_locked_page


PAGE_NAME = "insights"


def render_page() -> None:
    """Render rekomendasi."""

    st = _get_streamlit()
    st.set_page_config(page_title="Rekomendasi", page_icon="💡", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "sesi-utama"))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    dashboard_response = None

    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)
    state = build_onboarding_state(business_id=business_id, dashboard_response=dashboard_response)
    render_navigation(st, state)

    render_hero(st, eyebrow="Rekomendasi", title="Rekomendasi Bisnis", description="Lihat rekomendasi berbasis transaksi, produk, persediaan, dan pemasaran.")

    if not state.insights_ready:
        render_locked_page(st, message="Rekomendasi akan aktif setelah transaksi tersedia.", state=state, next_action_label="Catat Transaksi Pertama", next_page="pages/First_Transaction.py")
        return

    tab_context, tab_review, tab_save = st.tabs(["Konteks", "Daftar Rekomendasi", "Simpan Catatan"])

    with tab_context:
        if st.button("Muat Konteks Rekomendasi", type="primary"):
            response = client.get_insight_context({"business_id": business_id, "limit": limit, "session_id": session_id})
            _render_response(st, response)

    with tab_review:
        keyword = st.text_input("Kata Kunci")
        category = st.text_input("Kategori")
        if st.button("Muat Rekomendasi"):
            response = client.get_insight_review(business_id=business_id, keyword=keyword or None, insight_category=category or None, limit=limit)
            _render_response(st, response)

    with tab_save:
        with st.form("insight_form"):
            title = st.text_input("Judul")
            category_input = st.text_input("Kategori", value="general")
            priority = st.selectbox("Prioritas", ["low", "medium", "high"], format_func=_priority_label)
            content = st.text_area("Isi Rekomendasi")
            submit = st.form_submit_button("Simpan Rekomendasi")
        if submit:
            response = client.create_insight({
                "business_id": business_id,
                "insight_data": {"title": title, "insight_category": category_input, "content": content, "priority": priority},
                "session_id": session_id,
            })
            _render_response(st, response)


def _priority_label(value: str) -> str:
    """Priority label."""

    return {"low": "Rendah", "medium": "Sedang", "high": "Tinggi"}.get(value, value)


def _render_response(st: Any, response: Mapping[str, Any]) -> None:
    """Render response."""

    if not response.get("success"):
        st.error(_error_message(response))
        return
    st.success("Berhasil.")
    data = response.get("data")
    if isinstance(data, list):
        st.dataframe(data, use_container_width=True, hide_index=True)
    elif isinstance(data, Mapping):
        st.dataframe([{"Informasi": k, "Nilai": v} for k, v in data.items()], use_container_width=True, hide_index=True)


def _error_message(response: Mapping[str, Any]) -> str:
    """Error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])
    return "Permintaan belum berhasil."


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
