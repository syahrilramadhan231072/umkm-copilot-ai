"""
Produk
======
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_hero, render_locked_page, render_progress_indicator


PAGE_NAME = "marketing"


def render_page() -> None:
    """Render halaman produk."""

    st = _get_streamlit()
    st.set_page_config(page_title="Produk", page_icon="📦", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    dashboard_response = None

    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(
            business_id=business_id,
            limit=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)),
        )

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
        local_business_saved=bool(st.session_state.get("business_name")),
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 2",
        title="Produk",
        description="Produk adalah dasar untuk transaksi, persediaan, pemasaran, dan rekomendasi bisnis.",
    )
    render_progress_indicator(st, state)

    if not state.business_id_valid:
        render_locked_page(
            st,
            message="Ruang kerja belum terhubung. Selesaikan Profil Bisnis terlebih dahulu.",
            state=state,
            next_action_label="Buka Profil Bisnis",
            next_page="pages/Business_Profile.py",
        )
        return

    if state.has_products:
        st.success("Produk sudah terdeteksi dari backend.")
        if st.button("Lanjut ke Transaksi Pertama", type="primary"):
            switch_page(st, "pages/First_Transaction.py")
        return

    st.warning(
        "Backend saat ini belum menyediakan endpoint frontend untuk membuat produk baru."
    )
    st.caption(
        "Produk harus sudah tersedia di backend sebelum transaksi pertama dapat dicatat. "
        "Jika produk sudah dibuat oleh admin, muat ulang halaman ini."
    )

    with st.expander("Panduan data produk yang dibutuhkan"):
        st.write("Nama Produk")
        st.write("Harga Jual")
        st.write("Harga Modal")
        st.write("Stok Awal")
        st.write("Satuan")
        st.write("Kategori")

    if st.button("Periksa Produk Lagi", type="primary"):
        st.rerun()


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
