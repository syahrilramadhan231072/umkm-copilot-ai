"""
Pengaturan
==========
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_API_BASE_URL,
    DEFAULT_LIMIT,
    ensure_frontend_session,
    get_api_client_from_session_state,
)
from app.frontend.ui_components import render_hero


PAGE_NAME = "settings"


def render_page() -> None:
    """Render pengaturan."""

    st = _get_streamlit()
    st.set_page_config(page_title="Pengaturan", page_icon="⚙️", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    dashboard_response = None
    client = get_api_client_from_session_state(st.session_state)

    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(
            business_id=business_id,
            limit=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)),
        )
    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
        local_business_saved=bool(st.session_state.get("business_name")),
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Pengaturan",
        title="Preferensi Bisnis",
        description="Atur preferensi yang memengaruhi tampilan dan pengalaman aplikasi.",
    )

    with st.form("preferences_form"):
        business_name = st.text_input("Nama Bisnis", value=str(st.session_state.get("business_name", "")))
        currency = st.selectbox("Mata Uang", ["IDR", "USD"])
        timezone = st.selectbox("Zona Waktu", ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"])
        language = st.selectbox("Bahasa", ["Bahasa Indonesia"])
        submitted = st.form_submit_button("Simpan Preferensi", type="primary")

    if submitted:
        st.session_state["business_name"] = business_name.strip()
        st.session_state["currency"] = currency
        st.session_state["timezone"] = timezone
        st.session_state["language"] = language
        st.success("Preferensi tersimpan.")

    with st.expander("Lanjutan"):
        st.caption("Bagian ini untuk admin atau pengembang.")
        api_base_url = st.text_input("Alamat Backend", value=str(st.session_state.get("api_base_url", DEFAULT_API_BASE_URL)))
        workspace_code = st.text_input("Kode Ruang Kerja", value=str(st.session_state.get("business_id", "")), type="password")
        data_limit = st.number_input("Batas Data Dashboard", min_value=1, max_value=10000, value=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)), step=100)

        if st.button("Simpan Pengaturan Lanjutan"):
            st.session_state["api_base_url"] = api_base_url.strip().rstrip("/")
            st.session_state["business_id"] = workspace_code.strip()
            st.session_state["dashboard_limit"] = int(data_limit)
            if workspace_code and not is_valid_uuid(workspace_code):
                st.warning("Kode ruang kerja belum valid.")
            else:
                st.success("Pengaturan lanjutan tersimpan.")

        if st.button("Periksa Koneksi Backend"):
            response = get_api_client_from_session_state(st.session_state).health_check()
            if response.get("success"):
                st.success("Backend terhubung.")
            else:
                st.error("Backend belum terhubung.")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
