from __future__ import annotations

from app.frontend.onboarding import build_onboarding_state, get_current_step_number, is_valid_uuid


VALID_UUID = "11111111-1111-4111-8111-111111111111"


def test_invalid_business_id_stops_at_business_profile() -> None:
    state = build_onboarding_state(business_id="", local_business_saved=True)
    assert state.business_id_valid is False
    assert state.next_step == "business_profile"
    assert get_current_step_number(state) == 1


def test_valid_uuid_detection() -> None:
    assert is_valid_uuid(VALID_UUID) is True
    assert is_valid_uuid("bukan-kode-valid") is False


def test_ready_dashboard_state() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 3, "total_revenue": 100000},
        },
        "error": None,
    }
    state = build_onboarding_state(business_id=VALID_UUID, dashboard_response=response)
    assert state.dashboard_ready is True
    assert state.next_step == "dashboard"
    assert state.completion_percent == 100


def test_first_transaction_step_when_product_exists() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 0},
        },
        "error": None,
    }
    state = build_onboarding_state(business_id=VALID_UUID, dashboard_response=response)
    assert state.has_products is True
    assert state.has_transactions is False
    assert state.next_step == "first_transaction"
