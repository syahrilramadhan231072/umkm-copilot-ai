"""Main Streamlit entry point for UMKM Copilot AI."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.session import ensure_frontend_session, get_api_client_from_session_state


def render_app() -> None:
    """Render landing page."""

    st = _get_streamlit()
    st.set_page_config(page_title='UMKM Copilot AI', page_icon='UMKM', layout='wide')
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    st.title('UMKM Copilot AI')
    st.caption('Frontend Streamlit terhubung ke FastAPI backend.')
    st.info('Gunakan menu sidebar untuk membuka Dashboard, Transactions, Marketing, Insights, Export, AI Assistant, dan Settings.')

    with st.sidebar:
        st.subheader('Active Config')
        st.write(f"API: `{st.session_state['api_base_url']}`")
        st.write(f"Business ID: `{st.session_state['business_id']}`")
        st.write(f"Session ID: `{st.session_state['session_id']}`")

    if st.button('Check API Health', type='primary'):
        response = get_api_client_from_session_state(st.session_state).health_check()
        if response.get('success'):
            st.success('Backend connected.')
        else:
            st.error(_error_message(response))
        st.json(response)


def _error_message(response: dict[str, Any]) -> str:
    error = response.get('error')
    if isinstance(error, dict):
        return str(error.get('message', 'Request failed.'))
    return 'Request failed.'


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == '__main__':
    render_app()
