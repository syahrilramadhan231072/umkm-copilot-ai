"""
Status Onboarding
=================

Helper untuk menentukan kesiapan onboarding dari data backend.

Catatan arsitektur:
- Backend saat ini mendukung bisnis yang sudah disiapkan sebelumnya.
- Frontend tidak membuat bisnis baru.
- Frontend hanya mengecek apakah akses bisnis sudah aktif dan apakah data
  minimum untuk dashboard sudah tersedia.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping
from uuid import UUID


@dataclass(frozen=True)
class OnboardingState:
    """Status perjalanan onboarding."""

    business_id: str
    business_id_valid: bool
    service_reachable: bool
    has_business_access: bool
    has_products: bool
    has_transactions: bool
    dashboard_ready: bool
    marketing_ready: bool
    insights_ready: bool
    ai_ready: bool
    next_step: str
    completion_percent: int
    error_message: str | None = None


def build_onboarding_state(
    *,
    business_id: str,
    dashboard_response: Mapping[str, Any] | None = None,
) -> OnboardingState:
    """
    Bangun status onboarding.

    Args:
        business_id: Kunci akses bisnis internal yang disimpan frontend.
        dashboard_response: Response dashboard dari backend.

    Returns:
        OnboardingState.
    """

    business_id_valid = is_valid_uuid(business_id)

    if not business_id_valid:
        return OnboardingState(
            business_id=business_id,
            business_id_valid=False,
            service_reachable=False,
            has_business_access=False,
            has_products=False,
            has_transactions=False,
            dashboard_ready=False,
            marketing_ready=False,
            insights_ready=False,
            ai_ready=False,
            next_step="business_access",
            completion_percent=0,
            error_message="Akses bisnis belum aktif.",
        )

    if dashboard_response is None:
        return OnboardingState(
            business_id=business_id,
            business_id_valid=True,
            service_reachable=False,
            has_business_access=False,
            has_products=False,
            has_transactions=False,
            dashboard_ready=False,
            marketing_ready=False,
            insights_ready=False,
            ai_ready=False,
            next_step="business_access",
            completion_percent=10,
            error_message="Akses bisnis belum dapat diperiksa.",
        )

    if not bool(dashboard_response.get("success")):
        return OnboardingState(
            business_id=business_id,
            business_id_valid=True,
            service_reachable=True,
            has_business_access=False,
            has_products=False,
            has_transactions=False,
            dashboard_ready=False,
            marketing_ready=False,
            insights_ready=False,
            ai_ready=False,
            next_step="business_access",
            completion_percent=10,
            error_message=_extract_error_message(dashboard_response),
        )

    data = _ensure_mapping(dashboard_response.get("data"))
    has_products = _has_products(data)
    has_transactions = _has_transactions(data)
    dashboard_ready = has_products and has_transactions

    if not has_products:
        next_step = "products"
    elif not has_transactions:
        next_step = "first_transaction"
    else:
        next_step = "dashboard"

    completed_steps = 1 + int(has_products) + int(has_transactions)
    completion_percent = int((completed_steps / 3) * 100)

    return OnboardingState(
        business_id=business_id,
        business_id_valid=True,
        service_reachable=True,
        has_business_access=True,
        has_products=has_products,
        has_transactions=has_transactions,
        dashboard_ready=dashboard_ready,
        marketing_ready=has_products,
        insights_ready=has_transactions,
        ai_ready=dashboard_ready,
        next_step=next_step,
        completion_percent=completion_percent,
        error_message=None,
    )


def is_valid_uuid(value: str) -> bool:
    """
    Periksa apakah nilai adalah UUID valid.

    Args:
        value: Nilai yang diperiksa.

    Returns:
        True jika valid.
    """

    if not isinstance(value, str) or not value.strip():
        return False

    try:
        UUID(value.strip())
    except (ValueError, AttributeError, TypeError):
        return False

    return True


def get_current_step_number(state: OnboardingState) -> int:
    """
    Ambil nomor langkah aktif.

    Args:
        state: Status onboarding.

    Returns:
        Nomor langkah.
    """

    if not state.has_business_access:
        return 1

    if not state.has_products:
        return 2

    if not state.has_transactions:
        return 3

    return 4


def _has_products(data: Mapping[str, Any]) -> bool:
    """Deteksi ketersediaan produk dari dashboard data."""

    product_summary = _ensure_mapping(data.get("product_summary"))
    inventory_summary = _ensure_mapping(data.get("inventory_summary"))

    if _mapping_has_positive_value(
        product_summary,
        keywords=("product", "active", "total", "count"),
    ):
        return True

    if _mapping_has_positive_value(
        inventory_summary,
        keywords=("product", "stock", "item", "total", "count"),
    ):
        return True

    return _has_non_empty_records(
        data.get("top_products_by_revenue"),
    ) or _has_non_empty_records(
        data.get("top_products_by_quantity"),
    )


def _has_transactions(data: Mapping[str, Any]) -> bool:
    """Deteksi ketersediaan transaksi dari dashboard data."""

    sales_summary = _ensure_mapping(data.get("sales_summary"))

    if _mapping_has_positive_value(
        sales_summary,
        keywords=("transaction", "revenue", "sales", "quantity", "order", "total"),
    ):
        return True

    return _list_has_positive_metric(
        data.get("top_products_by_revenue"),
    ) or _list_has_positive_metric(
        data.get("top_products_by_quantity"),
    )


def _mapping_has_positive_value(
    mapping: Mapping[str, Any],
    *,
    keywords: tuple[str, ...],
) -> bool:
    """Cari nilai numerik positif pada mapping."""

    for key, value in mapping.items():
        normalized_key = str(key).lower()

        if any(keyword in normalized_key for keyword in keywords):
            number = _to_decimal(value)
            if number is not None and number > 0:
                return True

        if isinstance(value, Mapping) and _mapping_has_positive_value(
            value,
            keywords=keywords,
        ):
            return True

    return False


def _list_has_positive_metric(value: Any) -> bool:
    """Periksa apakah list memiliki metric positif."""

    if not isinstance(value, list):
        return False

    for item in value:
        if isinstance(item, Mapping):
            for metric_value in item.values():
                number = _to_decimal(metric_value)
                if number is not None and number > 0:
                    return True

    return False


def _has_non_empty_records(value: Any) -> bool:
    """Periksa apakah value adalah list tidak kosong."""

    return isinstance(value, list) and len(value) > 0


def _ensure_mapping(value: Any) -> dict[str, Any]:
    """Pastikan value berupa dictionary."""

    if isinstance(value, Mapping):
        return dict(value)

    return {}


def _to_decimal(value: Any) -> Decimal | None:
    """Konversi ke Decimal."""

    if isinstance(value, bool):
        return None

    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def _extract_error_message(response: Mapping[str, Any]) -> str:
    """Ambil pesan error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])

    return "Akses bisnis belum dapat dimuat."
