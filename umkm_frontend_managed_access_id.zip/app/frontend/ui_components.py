"""
Komponen UI Frontend
====================

Komponen visual reusable untuk Streamlit.
"""

from __future__ import annotations

from typing import Any

from app.frontend.navigation import switch_page
from app.frontend.onboarding import OnboardingState, get_current_step_number


def render_hero(
    st: Any,
    *,
    eyebrow: str,
    title: str,
    description: str,
) -> None:
    """
    Render hero section.

    Args:
        st: Modul Streamlit.
        eyebrow: Label kecil.
        title: Judul.
        description: Deskripsi.
    """

    st.markdown(
        f"""
        <section class="umkm-page-hero">
          <p class="umkm-page-hero__eyebrow">{eyebrow}</p>
          <h1 class="umkm-page-hero__title">{title}</h1>
          <p class="umkm-page-hero__description">{description}</p>
        </section>
        """,
        unsafe_allow_html=True,
    )


def render_progress_indicator(st: Any, state: OnboardingState) -> None:
    """
    Render indikator progres.

    Args:
        st: Modul Streamlit.
        state: Status onboarding.
    """

    current_step = get_current_step_number(state)
    progress = min(max(state.completion_percent, 0), 100)

    st.progress(progress, text=f"Langkah {current_step} dari 4")

    labels = ["Profil Bisnis", "Produk", "Transaksi Pertama", "Dashboard"]
    columns = st.columns(4)

    for index, label in enumerate(labels, start=1):
        with columns[index - 1]:
            if index < current_step:
                st.success(f"✓ {label}")
            elif index == current_step:
                st.info(f"• {label}")
            else:
                st.caption(label)


def render_locked_page(
    st: Any,
    *,
    message: str,
    state: OnboardingState,
    next_action_label: str,
    next_page: str,
) -> None:
    """
    Render halaman terkunci dengan arahan sederhana.

    Args:
        st: Modul Streamlit.
        message: Pesan.
        state: Status onboarding.
        next_action_label: Label tombol.
        next_page: Tujuan halaman.
    """

    st.warning(message)
    render_progress_indicator(st, state)

    if st.button(next_action_label, type="primary"):
        switch_page(st, next_page)


def render_api_error(st: Any, message: str) -> None:
    """
    Render pesan error yang ramah pengguna.

    Args:
        st: Modul Streamlit.
        message: Pesan.
    """

    st.error(message)
    st.caption("Silakan coba lagi atau hubungi pengelola aplikasi.")


def render_empty_state(
    st: Any,
    *,
    title: str,
    description: str,
    action_label: str | None = None,
    action_page: str | None = None,
) -> None:
    """
    Render empty state.

    Args:
        st: Modul Streamlit.
        title: Judul.
        description: Deskripsi.
        action_label: Label tombol.
        action_page: Tujuan halaman.
    """

    st.markdown(f"### {title}")
    st.caption(description)

    if action_label and action_page:
        if st.button(action_label, type="primary"):
            switch_page(st, action_page)


def render_response_table(st: Any, data: Any) -> None:
    """
    Render data response tanpa JSON mentah.

    Args:
        st: Modul Streamlit.
        data: Data dari response API.
    """

    if isinstance(data, list):
        st.dataframe(data, use_container_width=True, hide_index=True)
        return

    if isinstance(data, dict):
        rows = [
            {"Informasi": _humanize(str(key)), "Nilai": value}
            for key, value in data.items()
        ]
        st.dataframe(rows, use_container_width=True, hide_index=True)
        return

    if data is not None:
        st.write(str(data))


def _humanize(value: str) -> str:
    """Humanize key."""

    return value.replace("_", " ").replace("-", " ").title()
