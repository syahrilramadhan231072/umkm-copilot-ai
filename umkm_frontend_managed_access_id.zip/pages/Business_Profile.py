"""
Profil Bisnis
=============

Halaman ini tidak membuat bisnis baru. Backend saat ini menggunakan model
bisnis yang sudah disiapkan pengelola. Halaman ini hanya menjelaskan status
akses bisnis dan menyimpan preferensi tampilan pengguna.
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    ensure_frontend_session,
    get_api_client_from_session_state,
)
from app.frontend.ui_components import render_hero, render_progress_indicator


PAGE_NAME = "business_profile"


def render_page() -> None:
    """Render halaman profil bisnis."""

    st = _get_streamlit()
    st.set_page_config(page_title="Profil Bisnis", page_icon="🏪", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        with st.spinner("Memeriksa akses bisnis..."):
            dashboard_response = client.get_dashboard(
                business_id=business_id,
                limit=limit,
            )

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 1",
        title="Profil Bisnis",
        description=(
            "UMKM Copilot AI menggunakan bisnis yang sudah disiapkan oleh pengelola. "
            "Di halaman ini Anda dapat melihat status akses dan mengatur preferensi tampilan."
        ),
    )
    render_progress_indicator(st, state)

    if state.has_business_access:
        st.success("Akses bisnis sudah aktif.")
        st.caption("Anda dapat melanjutkan ke langkah Produk.")
    else:
        st.warning("Akses bisnis belum aktif.")
        st.caption(
            "Silakan hubungi pengelola aplikasi agar bisnis Anda dapat diaktifkan. "
            "Setelah aktif, aplikasi akan memeriksa produk dan transaksi secara otomatis."
        )

    st.divider()
    st.subheader("Preferensi Tampilan")

    with st.form("business_preferences_form"):
        business_name = st.text_input(
            "Nama Bisnis",
            value=str(st.session_state.get("business_name", "")),
            placeholder="Contoh: Kedai Kopi Nusantara",
        )
        owner_name = st.text_input(
            "Nama Pemilik",
            value=str(st.session_state.get("owner_name", "")),
            placeholder="Contoh: Ibu Sari",
        )
        business_type = st.text_input(
            "Jenis Bisnis",
            value=str(st.session_state.get("business_type", "")),
            placeholder="Contoh: Kuliner, Retail, Jasa",
        )
        currency = st.selectbox(
            "Mata Uang",
            ["IDR", "USD"],
            index=0 if st.session_state.get("currency", "IDR") == "IDR" else 1,
        )
        timezone = st.selectbox(
            "Zona Waktu",
            ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"],
        )
        submitted = st.form_submit_button("Simpan Preferensi", type="primary")

    if submitted:
        st.session_state["business_name"] = business_name.strip()
        st.session_state["owner_name"] = owner_name.strip()
        st.session_state["business_type"] = business_type.strip()
        st.session_state["currency"] = currency
        st.session_state["timezone"] = timezone
        st.success("Preferensi tersimpan.")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
