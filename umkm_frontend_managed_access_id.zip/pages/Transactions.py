"""
Transaksi
=========

Halaman transaksi setelah onboarding selesai.
"""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    ensure_frontend_session,
    get_api_client_from_session_state,
)
from app.frontend.ui_components import render_hero, render_locked_page, render_response_table


PAGE_NAME = "transactions"


def render_page() -> None:
    """Render halaman transaksi."""

    st = _get_streamlit()
    st.set_page_config(page_title="Transaksi", page_icon="🧾", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "sesi-utama"))
    product_id = str(st.session_state.get("default_product_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Transaksi",
        title="Kelola Transaksi",
        description="Catat penjualan dan lihat ringkasan transaksi bisnis.",
    )

    if not state.dashboard_ready:
        render_locked_page(
            st,
            message="Transaksi lengkap tersedia setelah penyiapan awal selesai.",
            state=state,
            next_action_label="Lanjutkan Penyiapan",
            next_page="app.py",
        )
        return

    tab_record, tab_summary = st.tabs(["Catat Penjualan", "Ringkasan"])

    with tab_record:
        if not product_id:
            st.warning("Produk default belum tersedia.")
            st.caption("Pengelola dapat mengatur produk default melalui Pengaturan > Lanjutan.")
        else:
            with st.form("transaction_form"):
                quantity = st.number_input("Jumlah Terjual", min_value=1, value=1, step=1)
                payment_method = st.selectbox(
                    "Metode Pembayaran",
                    ["cash", "qris", "transfer", "credit_card", "other"],
                    format_func=_payment_label,
                )
                notes = st.text_area("Catatan", value="")
                submitted = st.form_submit_button("Catat Penjualan", type="primary")

            if submitted:
                payload = {
                    "business_id": business_id,
                    "product_id": product_id,
                    "quantity": int(quantity),
                    "payment_method": str(payment_method),
                    "status": "completed",
                    "notes": notes,
                    "session_id": session_id,
                }
                with st.spinner("Mencatat penjualan..."):
                    response = client.record_transaction(payload)
                if response.get("success"):
                    st.success("Penjualan berhasil dicatat.")
                else:
                    st.error(_error_message(response))

    with tab_summary:
        if st.button("Muat Ringkasan Transaksi", type="primary"):
            with st.spinner("Memuat ringkasan transaksi..."):
                response = client.get_transaction_summary(
                    business_id=business_id,
                    limit=limit,
                )
            if response.get("success"):
                render_response_table(st, response.get("data"))
            else:
                st.error(_error_message(response))


def _payment_label(value: str) -> str:
    """Ubah label metode pembayaran."""

    labels = {
        "cash": "Tunai",
        "qris": "QRIS",
        "transfer": "Transfer",
        "credit_card": "Kartu Kredit",
        "other": "Lainnya",
    }

    return labels.get(value, value)


def _error_message(response: Mapping[str, Any]) -> str:
    """Ambil pesan error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])

    return "Permintaan belum berhasil."


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
