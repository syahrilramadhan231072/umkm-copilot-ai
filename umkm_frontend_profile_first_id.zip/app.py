"""
Beranda UMKM Copilot AI
=======================

Halaman awal dengan pendekatan profile-first:
pengguna mengisi profil bisnis sebagai acuan pengalaman aplikasi,
sementara data operasional tetap berasal dari backend.
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    has_local_business_profile,
)
from app.frontend.ui_components import (
    render_api_error,
    render_business_header,
    render_hero,
    render_progress_indicator,
)


def render_app() -> None:
    """Render halaman beranda."""

    st = _get_streamlit()
    st.set_page_config(
        page_title="UMKM Copilot AI",
        page_icon="🤖",
        layout="wide",
    )
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response: dict[str, Any] | None = None
    if is_valid_uuid(business_id):
        with st.spinner("Memeriksa kesiapan data bisnis..."):
            dashboard_response = client.get_dashboard(
                business_id=business_id,
                limit=limit,
            )

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        dashboard_response=dashboard_response,
    )

    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Selamat datang",
        title="UMKM Copilot AI",
        description=(
            "Mulai dari profil bisnis Anda. Aplikasi akan menggunakan profil tersebut "
            "sebagai acuan tampilan, analisis, dan pengalaman copilot."
        ),
    )

    if profile_ready:
        render_business_header(st, preferences)

    render_progress_indicator(st, state)
    st.divider()

    if state.dashboard_ready:
        st.success("Bisnis Anda sudah siap. Dashboard dan asisten bisnis dapat digunakan.")
        if st.button("Buka Dashboard", type="primary"):
            switch_page(st, "pages/Dashboard.py")
        return

    if state.next_step == "business_profile":
        st.markdown("### Lengkapi profil bisnis")
        st.caption(
            "Isi informasi dasar bisnis Anda. Identitas teknis aplikasi akan dikelola "
            "di belakang layar oleh pengelola aplikasi."
        )
        if st.button("Isi Profil Bisnis", type="primary"):
            switch_page(st, "pages/Business_Profile.py")
        return

    if state.next_step == "business_activation":
        st.markdown("### Profil bisnis sudah tersimpan")
        st.caption(
            "Profil bisnis sudah menjadi acuan tampilan aplikasi. Data operasional "
            "seperti produk, transaksi, dan dashboard akan aktif setelah pengelola "
            "menghubungkan data bisnis Anda."
        )
        action_col, secondary_col = st.columns([1, 1])
        with action_col:
            if st.button("Periksa Data Bisnis", type="primary"):
                st.rerun()
        with secondary_col:
            if st.button("Buka Pengaturan"):
                switch_page(st, "pages/Settings.py")
        if state.error_message:
            render_api_error(st, state.error_message)
        return

    if state.next_step == "products":
        st.markdown("### Data produk belum tersedia")
        st.caption(
            "Profil dan akses data bisnis sudah aktif. Produk perlu tersedia agar "
            "transaksi dan dashboard dapat berjalan."
        )
        if st.button("Buka Produk", type="primary"):
            switch_page(st, "pages/Products.py")
        return

    if state.next_step == "first_transaction":
        st.markdown("### Catat transaksi pertama")
        st.caption(
            "Produk sudah tersedia. Catat penjualan pertama untuk membuka dashboard lengkap."
        )
        if st.button("Catat Transaksi Pertama", type="primary"):
            switch_page(st, "pages/First_Transaction.py")


def _get_streamlit() -> Any:
    """Import Streamlit secara lazy."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_app()
