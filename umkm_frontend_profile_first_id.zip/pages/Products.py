"""
Produk
======

Halaman status produk. Produk tidak dibuat dari frontend karena backend saat ini
belum menyediakan endpoint pembuatan produk untuk onboarding mandiri.
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    has_local_business_profile,
)
from app.frontend.ui_components import (
    render_business_header,
    render_hero,
    render_locked_page,
    render_progress_indicator,
)


PAGE_NAME = "products"


def render_page() -> None:
    """Render halaman produk."""

    st = _get_streamlit()
    st.set_page_config(page_title="Produk", page_icon="📦", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        with st.spinner("Memeriksa data produk..."):
            dashboard_response = client.get_dashboard(
                business_id=business_id,
                limit=limit,
            )

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 2",
        title="Produk",
        description="Produk menjadi dasar transaksi, persediaan, pemasaran, dan rekomendasi.",
    )

    if profile_ready:
        render_business_header(st, preferences)

    render_progress_indicator(st, state)

    if not state.business_profile_ready:
        render_locked_page(
            st,
            message="Profil bisnis belum lengkap.",
            state=state,
            next_action_label="Isi Profil Bisnis",
            next_page="pages/Business_Profile.py",
        )
        return

    if not state.has_business_access:
        st.warning("Data produk belum aktif.")
        st.caption(
            "Profil bisnis sudah tersimpan, tetapi data operasional belum terhubung. "
            "Pengelola aplikasi perlu mengaktifkan data bisnis agar produk dapat dibaca."
        )
        if st.button("Periksa Lagi", type="primary"):
            st.rerun()
        return

    if state.has_products:
        st.success("Produk sudah tersedia.")
        st.caption("Anda dapat melanjutkan ke transaksi pertama.")
        if st.button("Lanjut ke Transaksi Pertama", type="primary"):
            switch_page(st, "pages/First_Transaction.py")
        return

    st.warning("Produk belum tersedia.")
    st.caption(
        "Produk perlu tersedia sebelum transaksi pertama dapat dicatat. "
        "Silakan hubungi pengelola aplikasi jika produk belum muncul."
    )

    if st.button("Periksa Produk Lagi", type="primary"):
        st.rerun()


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
