from __future__ import annotations

from app.frontend.onboarding import (
    build_onboarding_state,
    get_current_step_number,
    is_valid_uuid,
)


VALID_UUID = "11111111-1111-4111-8111-111111111111"


def test_profile_missing_stops_at_profile() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=False,
    )
    assert state.business_profile_ready is False
    assert state.next_step == "business_profile"
    assert get_current_step_number(state) == 1


def test_profile_ready_but_data_not_active() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=True,
    )
    assert state.business_profile_ready is True
    assert state.has_business_access is False
    assert state.next_step == "business_activation"
    assert get_current_step_number(state) == 1


def test_valid_uuid_detection() -> None:
    assert is_valid_uuid(VALID_UUID) is True
    assert is_valid_uuid("bukan-kunci-valid") is False


def test_product_step_when_business_exists_but_no_products() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 0},
            "sales_summary": {"total_transactions": 0},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        business_profile_ready=True,
        dashboard_response=response,
    )
    assert state.has_business_access is True
    assert state.has_products is False
    assert state.next_step == "products"
    assert get_current_step_number(state) == 2


def test_first_transaction_step_when_products_exist() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 0},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        business_profile_ready=True,
        dashboard_response=response,
    )
    assert state.has_products is True
    assert state.has_transactions is False
    assert state.next_step == "first_transaction"
    assert get_current_step_number(state) == 3


def test_dashboard_ready_state() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 3, "total_revenue": 100000},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        business_profile_ready=True,
        dashboard_response=response,
    )
    assert state.dashboard_ready is True
    assert state.next_step == "dashboard"
    assert state.completion_percent == 100
    assert get_current_step_number(state) == 4
