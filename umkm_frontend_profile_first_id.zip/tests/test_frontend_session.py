from __future__ import annotations

from app.frontend.session import (
    build_business_preferences,
    ensure_frontend_session,
    has_local_business_profile,
)


def test_frontend_session_defaults() -> None:
    session_state = {}
    ensure_frontend_session(session_state)
    assert session_state["currency"] == "IDR"
    assert session_state["timezone"] == "Asia/Jakarta"


def test_local_business_profile_requires_core_fields() -> None:
    session_state = {
        "business_name": "Kedai Kopi",
        "owner_name": "Sari",
        "business_type": "Kuliner",
    }
    ensure_frontend_session(session_state)
    assert has_local_business_profile(session_state) is True


def test_business_preferences_builds_display_values() -> None:
    session_state = {
        "business_name": "Kedai Kopi",
        "owner_name": "Sari",
        "business_type": "Kuliner",
        "currency": "IDR",
        "timezone": "Asia/Jakarta",
        "language": "Bahasa Indonesia",
    }
    ensure_frontend_session(session_state)
    preferences = build_business_preferences(session_state)
    assert preferences["business_name"] == "Kedai Kopi"
    assert preferences["currency"] == "IDR"
