"""
Status Onboarding
=================

Helper untuk menentukan kesiapan onboarding dari data backend dan data penyiapan lokal.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping
from uuid import UUID


@dataclass(frozen=True)
class OnboardingState:
    """Status perjalanan onboarding."""

    business_profile_ready: bool
    business_id: str
    business_id_valid: bool
    service_reachable: bool
    has_business_access: bool
    backend_has_products: bool
    backend_has_transactions: bool
    local_product_count: int
    local_transaction_count: int
    has_products: bool
    has_transactions: bool
    dashboard_ready: bool
    operational_dashboard_ready: bool
    marketing_ready: bool
    insights_ready: bool
    ai_ready: bool
    next_step: str
    completion_percent: int
    error_message: str | None = None


def build_onboarding_state(
    *,
    business_id: str,
    business_profile_ready: bool,
    local_product_count: int = 0,
    local_transaction_count: int = 0,
    dashboard_response: Mapping[str, Any] | None = None,
) -> OnboardingState:
    """Bangun status onboarding."""

    business_id_valid = is_valid_uuid(business_id)
    backend_has_products = False
    backend_has_transactions = False
    service_reachable = False
    has_business_access = False
    error_message: str | None = None

    if business_id_valid and dashboard_response is not None:
        service_reachable = True
        if bool(dashboard_response.get("success")):
            has_business_access = True
            data = _ensure_mapping(dashboard_response.get("data"))
            backend_has_products = _has_products(data)
            backend_has_transactions = _has_transactions(data)
        else:
            error_message = _extract_error_message(dashboard_response)

    has_products = backend_has_products or local_product_count > 0
    has_transactions = backend_has_transactions or local_transaction_count > 0
    dashboard_ready = business_profile_ready and has_products and has_transactions
    operational_dashboard_ready = (
        has_business_access and backend_has_products and backend_has_transactions
    )

    if not business_profile_ready:
        next_step = "business_profile"
    elif not has_products:
        next_step = "products"
    elif not has_transactions:
        next_step = "first_transaction"
    else:
        next_step = "dashboard"

    completed_steps = int(business_profile_ready) + int(has_products) + int(has_transactions)
    completion_percent = int((completed_steps / 3) * 100)

    return OnboardingState(
        business_profile_ready=business_profile_ready,
        business_id=business_id,
        business_id_valid=business_id_valid,
        service_reachable=service_reachable,
        has_business_access=has_business_access,
        backend_has_products=backend_has_products,
        backend_has_transactions=backend_has_transactions,
        local_product_count=local_product_count,
        local_transaction_count=local_transaction_count,
        has_products=has_products,
        has_transactions=has_transactions,
        dashboard_ready=dashboard_ready,
        operational_dashboard_ready=operational_dashboard_ready,
        marketing_ready=has_products,
        insights_ready=has_transactions,
        ai_ready=dashboard_ready,
        next_step=next_step,
        completion_percent=completion_percent,
        error_message=error_message,
    )


def is_valid_uuid(value: str) -> bool:
    """Periksa apakah nilai adalah UUID valid."""

    if not isinstance(value, str) or not value.strip():
        return False

    try:
        UUID(value.strip())
    except (ValueError, AttributeError, TypeError):
        return False

    return True


def get_current_step_number(state: OnboardingState) -> int:
    """Ambil nomor langkah aktif."""

    if not state.business_profile_ready:
        return 1

    if not state.has_products:
        return 2

    if not state.has_transactions:
        return 3

    return 4


def _has_products(data: Mapping[str, Any]) -> bool:
    """Deteksi ketersediaan produk dari dashboard data."""

    product_summary = _ensure_mapping(data.get("product_summary"))
    inventory_summary = _ensure_mapping(data.get("inventory_summary"))

    if _mapping_has_positive_value(
        product_summary,
        keywords=("product", "active", "total", "count"),
    ):
        return True

    if _mapping_has_positive_value(
        inventory_summary,
        keywords=("product", "stock", "item", "total", "count"),
    ):
        return True

    return _has_non_empty_records(
        data.get("top_products_by_revenue"),
    ) or _has_non_empty_records(
        data.get("top_products_by_quantity"),
    )


def _has_transactions(data: Mapping[str, Any]) -> bool:
    """Deteksi ketersediaan transaksi dari dashboard data."""

    sales_summary = _ensure_mapping(data.get("sales_summary"))

    if _mapping_has_positive_value(
        sales_summary,
        keywords=("transaction", "revenue", "sales", "quantity", "order", "total"),
    ):
        return True

    return _list_has_positive_metric(
        data.get("top_products_by_revenue"),
    ) or _list_has_positive_metric(
        data.get("top_products_by_quantity"),
    )


def _mapping_has_positive_value(
    mapping: Mapping[str, Any],
    *,
    keywords: tuple[str, ...],
) -> bool:
    """Cari nilai numerik positif pada mapping."""

    for key, value in mapping.items():
        normalized_key = str(key).lower()

        if any(keyword in normalized_key for keyword in keywords):
            number = _to_decimal(value)
            if number is not None and number > 0:
                return True

        if isinstance(value, Mapping) and _mapping_has_positive_value(
            value,
            keywords=keywords,
        ):
            return True

    return False


def _list_has_positive_metric(value: Any) -> bool:
    """Periksa apakah list memiliki metric positif."""

    if not isinstance(value, list):
        return False

    for item in value:
        if isinstance(item, Mapping):
            for metric_value in item.values():
                number = _to_decimal(metric_value)
                if number is not None and number > 0:
                    return True

    return False


def _has_non_empty_records(value: Any) -> bool:
    """Periksa apakah value adalah list tidak kosong."""

    return isinstance(value, list) and len(value) > 0


def _ensure_mapping(value: Any) -> dict[str, Any]:
    """Pastikan value berupa dictionary."""

    if isinstance(value, Mapping):
        return dict(value)

    return {}


def _to_decimal(value: Any) -> Decimal | None:
    """Konversi ke Decimal."""

    if isinstance(value, bool):
        return None

    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def _extract_error_message(response: Mapping[str, Any]) -> str:
    """Ambil pesan error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])

    return "Data operasional bisnis belum dapat dimuat."
