"""
Session Frontend
================

Helper session state untuk Streamlit.

Catatan:
- Profil, produk, dan transaksi dapat disimpan sebagai data penyiapan lokal.
- Jika backend sudah terhubung, data backend tetap menjadi sumber operasional.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, MutableMapping

from app.frontend.api_client import FrontendApiClient


DEFAULT_API_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_BUSINESS_ID = ""
DEFAULT_SESSION_ID = "sesi-utama"
DEFAULT_LIMIT = 1000
DEFAULT_CURRENCY = "IDR"
DEFAULT_TIMEZONE = "Asia/Jakarta"
DEFAULT_LANGUAGE = "Bahasa Indonesia"
DEFAULT_PRODUCT_ACCESS_KEY = ""


def ensure_frontend_session(session_state: MutableMapping[str, Any]) -> None:
    """Pastikan semua kunci session tersedia."""

    session_state.setdefault("api_base_url", DEFAULT_API_BASE_URL)
    session_state.setdefault("business_id", DEFAULT_BUSINESS_ID)
    session_state.setdefault("session_id", DEFAULT_SESSION_ID)
    session_state.setdefault("dashboard_limit", DEFAULT_LIMIT)
    session_state.setdefault("business_name", "")
    session_state.setdefault("owner_name", "")
    session_state.setdefault("business_type", "")
    session_state.setdefault("currency", DEFAULT_CURRENCY)
    session_state.setdefault("timezone", DEFAULT_TIMEZONE)
    session_state.setdefault("language", DEFAULT_LANGUAGE)
    session_state.setdefault("default_product_id", DEFAULT_PRODUCT_ACCESS_KEY)
    session_state.setdefault("saved_business_profiles", [])
    session_state.setdefault("local_products", [])
    session_state.setdefault("local_transactions", [])


def get_api_client_from_session_state(
    session_state: MutableMapping[str, Any],
) -> FrontendApiClient:
    """Bangun API client dari session state."""

    ensure_frontend_session(session_state)

    return FrontendApiClient(api_base_url=str(session_state["api_base_url"]))


def has_local_business_profile(session_state: MutableMapping[str, Any]) -> bool:
    """Periksa apakah profil bisnis aktif sudah diisi."""

    ensure_frontend_session(session_state)

    required_values = [
        str(session_state.get("business_name", "")).strip(),
        str(session_state.get("owner_name", "")).strip(),
        str(session_state.get("business_type", "")).strip(),
    ]

    return all(required_values)


def build_business_preferences(
    session_state: MutableMapping[str, Any],
) -> dict[str, str]:
    """Bangun preferensi bisnis aktif."""

    ensure_frontend_session(session_state)

    return {
        "business_name": str(session_state.get("business_name", "")).strip(),
        "owner_name": str(session_state.get("owner_name", "")).strip(),
        "business_type": str(session_state.get("business_type", "")).strip(),
        "currency": str(session_state.get("currency", DEFAULT_CURRENCY)).strip(),
        "timezone": str(session_state.get("timezone", DEFAULT_TIMEZONE)).strip(),
        "language": str(session_state.get("language", DEFAULT_LANGUAGE)).strip(),
    }


def get_saved_business_profiles(
    session_state: MutableMapping[str, Any],
) -> list[dict[str, str]]:
    """Ambil daftar profil bisnis tersimpan."""

    ensure_frontend_session(session_state)
    profiles = session_state.get("saved_business_profiles", [])

    if isinstance(profiles, list):
        return [dict(profile) for profile in profiles if isinstance(profile, dict)]

    return []


def save_business_profile(
    session_state: MutableMapping[str, Any],
    profile: dict[str, str],
) -> None:
    """Simpan profil bisnis dan jadikan profil aktif."""

    ensure_frontend_session(session_state)
    normalized = {
        "business_name": profile["business_name"].strip(),
        "owner_name": profile["owner_name"].strip(),
        "business_type": profile["business_type"].strip(),
        "currency": profile["currency"].strip(),
        "timezone": profile["timezone"].strip(),
        "language": profile.get("language", DEFAULT_LANGUAGE).strip(),
    }

    profiles = get_saved_business_profiles(session_state)
    replaced = False

    for index, existing in enumerate(profiles):
        if existing.get("business_name", "").lower() == normalized["business_name"].lower():
            profiles[index] = normalized
            replaced = True
            break

    if not replaced:
        profiles.append(normalized)

    session_state["saved_business_profiles"] = profiles
    use_business_profile(session_state, normalized)


def use_business_profile(
    session_state: MutableMapping[str, Any],
    profile: dict[str, str],
) -> None:
    """Jadikan profil bisnis sebagai profil aktif."""

    ensure_frontend_session(session_state)
    session_state["business_name"] = profile.get("business_name", "").strip()
    session_state["owner_name"] = profile.get("owner_name", "").strip()
    session_state["business_type"] = profile.get("business_type", "").strip()
    session_state["currency"] = profile.get("currency", DEFAULT_CURRENCY).strip()
    session_state["timezone"] = profile.get("timezone", DEFAULT_TIMEZONE).strip()
    session_state["language"] = profile.get("language", DEFAULT_LANGUAGE).strip()


def get_local_products(
    session_state: MutableMapping[str, Any],
) -> list[dict[str, Any]]:
    """Ambil daftar produk penyiapan lokal."""

    ensure_frontend_session(session_state)
    products = session_state.get("local_products", [])

    if isinstance(products, list):
        return [dict(product) for product in products if isinstance(product, dict)]

    return []


def add_local_product(
    session_state: MutableMapping[str, Any],
    product: dict[str, Any],
) -> None:
    """Tambahkan produk penyiapan lokal."""

    ensure_frontend_session(session_state)
    products = get_local_products(session_state)
    product_number = len(products) + 1
    normalized = {
        "nama_produk": str(product["nama_produk"]).strip(),
        "harga_jual": float(product["harga_jual"]),
        "harga_modal": float(product["harga_modal"]),
        "stok_awal": int(product["stok_awal"]),
        "satuan": str(product["satuan"]).strip(),
        "kategori": str(product["kategori"]).strip(),
        "nomor_produk": product_number,
    }
    products.append(normalized)
    session_state["local_products"] = products


def get_local_transactions(
    session_state: MutableMapping[str, Any],
) -> list[dict[str, Any]]:
    """Ambil daftar transaksi penyiapan lokal."""

    ensure_frontend_session(session_state)
    transactions = session_state.get("local_transactions", [])

    if isinstance(transactions, list):
        return [
            dict(transaction)
            for transaction in transactions
            if isinstance(transaction, dict)
        ]

    return []


def add_local_transaction(
    session_state: MutableMapping[str, Any],
    transaction: dict[str, Any],
) -> None:
    """Tambahkan transaksi penyiapan lokal."""

    ensure_frontend_session(session_state)
    transactions = get_local_transactions(session_state)
    normalized = {
        "tanggal": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "nama_produk": str(transaction["nama_produk"]).strip(),
        "jumlah": int(transaction["jumlah"]),
        "harga_jual": float(transaction["harga_jual"]),
        "metode_pembayaran": str(transaction["metode_pembayaran"]).strip(),
        "catatan": str(transaction.get("catatan", "")).strip(),
    }
    normalized["total"] = normalized["jumlah"] * normalized["harga_jual"]
    transactions.append(normalized)
    session_state["local_transactions"] = transactions


def build_common_payload(
    session_state: MutableMapping[str, Any],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Bangun payload umum untuk endpoint yang membutuhkan konteks bisnis."""

    ensure_frontend_session(session_state)

    payload = {
        "business_id": str(session_state["business_id"]),
        "session_id": str(session_state["session_id"]),
    }

    if extra:
        payload.update(extra)

    return payload
