"""
Asisten AI
==========
"""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_local_products,
    get_local_transactions,
    has_local_business_profile,
)
from app.frontend.ui_components import render_business_header, render_hero, render_locked_page


PAGE_NAME = "ai_assistant"


def render_page() -> None:
    """Render asisten AI."""

    st = _get_streamlit()
    st.set_page_config(page_title="Asisten AI", page_icon="🤖", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)
    st.session_state.setdefault("chat_messages", [])

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "sesi-utama"))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    products = get_local_products(st.session_state)
    transactions = get_local_transactions(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        local_product_count=len(products),
        local_transaction_count=len(transactions),
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Asisten AI",
        title="Tanya Copilot Bisnis Anda",
        description="Ajukan pertanyaan tentang penjualan, produk, stok, dan promosi.",
    )

    if profile_ready:
        render_business_header(st, preferences)

    if not state.ai_ready:
        render_locked_page(
            st,
            message="Asisten AI akan aktif setelah profil, produk, dan transaksi tersedia.",
            state=state,
            next_action_label="Lanjutkan Penyiapan",
            next_page="app.py",
        )
        return

    if not state.has_business_access:
        st.info(
            "Asisten berbasis layanan akan aktif setelah data operasional dihubungkan. "
            "Saat ini Anda tetap dapat melihat ringkasan awal pada Dashboard."
        )
        return

    for message in st.session_state["chat_messages"]:
        with st.chat_message(str(message["role"])):
            st.write(str(message["content"]))

    user_input = st.chat_input("Tulis pertanyaan Anda...")
    if user_input:
        st.session_state["chat_messages"].append({"role": "user", "content": user_input})
        with st.spinner("Asisten sedang membaca data bisnis..."):
            response = client.route(
                user_input=user_input,
                payload={
                    "business_id": business_id,
                    "session_id": session_id,
                    "user_message": user_input,
                    "business_profile": preferences,
                },
            )
        answer = _answer(response)
        st.session_state["chat_messages"].append({"role": "assistant", "content": answer})
        st.rerun()

    if st.button("Hapus Percakapan"):
        st.session_state["chat_messages"] = []
        st.rerun()


def _answer(response: Mapping[str, Any]) -> str:
    """Extract answer."""

    if not response.get("success"):
        error = response.get("error")
        if isinstance(error, Mapping) and error.get("message"):
            return f"Maaf, terjadi kendala: {error['message']}"
        return "Maaf, terjadi kendala."

    return "Permintaan berhasil diproses."


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
