"""
Profil Bisnis
=============
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_local_products,
    get_local_transactions,
    get_saved_business_profiles,
    has_local_business_profile,
    save_business_profile,
    use_business_profile,
)
from app.frontend.ui_components import (
    render_business_header,
    render_hero,
    render_progress_indicator,
)


PAGE_NAME = "business_profile"


def render_page() -> None:
    """Render halaman profil bisnis."""

    st = _get_streamlit()
    st.set_page_config(page_title="Profil Bisnis", page_icon="🏪", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    products = get_local_products(st.session_state)
    transactions = get_local_transactions(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        local_product_count=len(products),
        local_transaction_count=len(transactions),
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 1",
        title="Profil Bisnis",
        description=(
            "Gunakan profil bisnis yang sudah ada atau buat profil baru untuk memulai."
        ),
    )

    if profile_ready:
        render_business_header(st, preferences)

    render_progress_indicator(st, state)

    saved_profiles = get_saved_business_profiles(st.session_state)
    if saved_profiles:
        st.subheader("Profil bisnis tersimpan")
        for index, profile in enumerate(saved_profiles):
            col_info, col_action = st.columns([3, 1])
            with col_info:
                st.markdown(f"**{profile.get('business_name', 'Bisnis')}**")
                st.caption(
                    f"{profile.get('business_type', '-')} · "
                    f"Pemilik: {profile.get('owner_name', '-')}"
                )
            with col_action:
                if st.button("Gunakan", key=f"use_profile_{index}"):
                    use_business_profile(st.session_state, profile)
                    st.success("Profil bisnis digunakan.")
                    st.rerun()

        st.divider()

    st.subheader("Buat atau perbarui profil")
    with st.form("business_profile_form"):
        business_name = st.text_input(
            "Nama Bisnis",
            value=str(st.session_state.get("business_name", "")),
            placeholder="Contoh: Kedai Kopi Nusantara",
        )
        owner_name = st.text_input(
            "Nama Pemilik",
            value=str(st.session_state.get("owner_name", "")),
            placeholder="Contoh: Ibu Sari",
        )
        business_type = st.text_input(
            "Jenis Usaha",
            value=str(st.session_state.get("business_type", "")),
            placeholder="Contoh: Kuliner, Retail, Jasa",
        )
        currency = st.selectbox(
            "Mata Uang",
            ["IDR", "USD"],
            index=0 if st.session_state.get("currency", "IDR") == "IDR" else 1,
        )
        timezone_options = ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"]
        current_timezone = str(st.session_state.get("timezone", "Asia/Jakarta"))
        timezone_index = timezone_options.index(current_timezone) if current_timezone in timezone_options else 0
        timezone = st.selectbox(
            "Zona Waktu",
            timezone_options,
            index=timezone_index,
        )
        submitted = st.form_submit_button("Simpan Profil Bisnis", type="primary")

    if submitted:
        if not business_name.strip() or not owner_name.strip() or not business_type.strip():
            st.warning("Lengkapi Nama Bisnis, Nama Pemilik, dan Jenis Usaha.")
            return

        save_business_profile(
            st.session_state,
            {
                "business_name": business_name,
                "owner_name": owner_name,
                "business_type": business_type,
                "currency": currency,
                "timezone": timezone,
                "language": "Bahasa Indonesia",
            },
        )
        st.success("Profil bisnis tersimpan dan siap digunakan.")
        st.rerun()

    if has_local_business_profile(st.session_state):
        if st.button("Lanjut ke Produk", type="primary"):
            switch_page(st, "pages/Products.py")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
