"""
Transaksi Pertama
=================
"""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    add_local_transaction,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_local_products,
    get_local_transactions,
    has_local_business_profile,
)
from app.frontend.ui_components import (
    render_business_header,
    render_hero,
    render_locked_page,
    render_progress_indicator,
)


PAGE_NAME = "first_transaction"


def render_page() -> None:
    """Render halaman transaksi pertama."""

    st = _get_streamlit()
    st.set_page_config(page_title="Transaksi Pertama", page_icon="🧾", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "sesi-utama"))
    default_product_id = str(st.session_state.get("default_product_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    products = get_local_products(st.session_state)
    transactions = get_local_transactions(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        local_product_count=len(products),
        local_transaction_count=len(transactions),
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 3",
        title="Transaksi Pertama",
        description="Catat penjualan pertama untuk membuka dashboard.",
    )

    if profile_ready:
        render_business_header(st, preferences)

    render_progress_indicator(st, state)

    if not state.business_profile_ready:
        render_locked_page(
            st,
            message="Profil bisnis belum lengkap.",
            state=state,
            next_action_label="Isi Profil Bisnis",
            next_page="pages/Business_Profile.py",
        )
        return

    if not state.has_products:
        render_locked_page(
            st,
            message="Produk belum tersedia.",
            state=state,
            next_action_label="Buka Produk",
            next_page="pages/Products.py",
        )
        return

    if transactions:
        st.subheader("Transaksi tersimpan")
        st.dataframe(transactions, use_container_width=True, hide_index=True)

    product_names = [str(product["nama_produk"]) for product in products]
    if not product_names and state.backend_has_products:
        st.info(
            "Produk operasional sudah terdeteksi. Untuk pencatatan langsung ke layanan, "
            "pengelola dapat mengatur produk default pada Pengaturan > Lanjutan."
        )

    st.subheader("Catat Penjualan")
    with st.form("first_transaction_form"):
        if product_names:
            selected_product_name = st.selectbox("Produk", product_names)
            selected_product = _find_product(products, selected_product_name)
            selling_price = float(selected_product.get("harga_jual", 0.0))
            st.caption(f"Harga jual: Rp{int(selling_price):,}".replace(",", "."))
        else:
            selected_product_name = "Produk Operasional"
            selling_price = 0.0

        quantity = st.number_input("Jumlah Terjual", min_value=1, value=1, step=1)
        payment_method = st.selectbox(
            "Metode Pembayaran",
            ["Tunai", "QRIS", "Transfer", "Kartu Kredit", "Lainnya"],
        )
        notes = st.text_area("Catatan", value="Transaksi pertama")
        submitted = st.form_submit_button("Catat Transaksi", type="primary")

    if submitted:
        if product_names:
            add_local_transaction(
                st.session_state,
                {
                    "nama_produk": selected_product_name,
                    "jumlah": int(quantity),
                    "harga_jual": selling_price,
                    "metode_pembayaran": str(payment_method),
                    "catatan": notes,
                },
            )
            st.success("Transaksi berhasil disimpan.")
            st.rerun()

        elif state.has_business_access and default_product_id:
            response = client.record_transaction(
                {
                    "business_id": business_id,
                    "product_id": default_product_id,
                    "quantity": int(quantity),
                    "payment_method": _payment_value(str(payment_method)),
                    "status": "completed",
                    "notes": notes,
                    "session_id": session_id,
                }
            )
            if response.get("success"):
                st.success("Transaksi berhasil dicatat.")
                st.rerun()
            else:
                st.error(_error_message(response))
        else:
            st.warning("Produk belum dapat dipilih.")

    if get_local_transactions(st.session_state) or state.backend_has_transactions:
        if st.button("Buka Dashboard", type="primary"):
            switch_page(st, "pages/Dashboard.py")


def _find_product(products: list[dict[str, Any]], product_name: str) -> dict[str, Any]:
    """Cari produk berdasarkan nama."""

    for product in products:
        if str(product.get("nama_produk")) == product_name:
            return product

    return {}


def _payment_value(label: str) -> str:
    """Konversi label pembayaran."""

    values = {
        "Tunai": "cash",
        "QRIS": "qris",
        "Transfer": "transfer",
        "Kartu Kredit": "credit_card",
        "Lainnya": "other",
    }

    return values.get(label, "other")


def _error_message(response: Mapping[str, Any]) -> str:
    """Ambil pesan error."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])

    return "Transaksi belum berhasil dicatat."


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
