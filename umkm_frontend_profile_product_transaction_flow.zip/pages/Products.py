"""
Produk
======
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation, switch_page
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    add_local_product,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_local_products,
    get_local_transactions,
    has_local_business_profile,
)
from app.frontend.ui_components import (
    render_business_header,
    render_hero,
    render_locked_page,
    render_progress_indicator,
)


PAGE_NAME = "products"


def render_page() -> None:
    """Render halaman produk."""

    st = _get_streamlit()
    st.set_page_config(page_title="Produk", page_icon="📦", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    products = get_local_products(st.session_state)
    transactions = get_local_transactions(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        local_product_count=len(products),
        local_transaction_count=len(transactions),
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Langkah 2",
        title="Produk",
        description="Tambahkan produk yang akan menjadi dasar transaksi dan dashboard awal.",
    )

    if profile_ready:
        render_business_header(st, preferences)

    render_progress_indicator(st, state)

    if not state.business_profile_ready:
        render_locked_page(
            st,
            message="Profil bisnis belum lengkap.",
            state=state,
            next_action_label="Isi Profil Bisnis",
            next_page="pages/Business_Profile.py",
        )
        return

    if products:
        st.subheader("Produk tersimpan")
        st.dataframe(products, use_container_width=True, hide_index=True)

    st.subheader("Tambah Produk")
    with st.form("product_form"):
        product_name = st.text_input("Nama Produk", placeholder="Contoh: Kopi Susu Gula Aren")
        selling_price = st.number_input("Harga Jual", min_value=0.0, value=0.0, step=1000.0)
        cost_price = st.number_input("Harga Modal", min_value=0.0, value=0.0, step=1000.0)
        initial_stock = st.number_input("Stok Awal", min_value=0, value=0, step=1)
        unit = st.text_input("Satuan", value="pcs")
        category = st.text_input("Kategori", value="Umum")
        submitted = st.form_submit_button("Simpan Produk", type="primary")

    if submitted:
        if not product_name.strip():
            st.warning("Nama produk wajib diisi.")
            return

        add_local_product(
            st.session_state,
            {
                "nama_produk": product_name,
                "harga_jual": float(selling_price),
                "harga_modal": float(cost_price),
                "stok_awal": int(initial_stock),
                "satuan": unit,
                "kategori": category,
            },
        )
        st.success("Produk berhasil disimpan.")
        st.rerun()

    if get_local_products(st.session_state) or state.backend_has_products:
        if st.button("Lanjut ke Transaksi Pertama", type="primary"):
            switch_page(st, "pages/First_Transaction.py")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
