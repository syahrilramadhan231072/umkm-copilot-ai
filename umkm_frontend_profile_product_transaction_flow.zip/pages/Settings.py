"""
Pengaturan
==========
"""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_frontend_assets
from app.frontend.navigation import render_navigation
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_API_BASE_URL,
    DEFAULT_LIMIT,
    build_business_preferences,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_local_products,
    get_local_transactions,
    has_local_business_profile,
)
from app.frontend.ui_components import render_business_header, render_hero


PAGE_NAME = "settings"


def render_page() -> None:
    """Render pengaturan."""

    st = _get_streamlit()
    st.set_page_config(page_title="Pengaturan", page_icon="⚙️", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    profile_ready = has_local_business_profile(st.session_state)
    preferences = build_business_preferences(st.session_state)
    products = get_local_products(st.session_state)
    transactions = get_local_transactions(st.session_state)
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    dashboard_response = None
    if is_valid_uuid(business_id):
        dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(
        business_id=business_id,
        business_profile_ready=profile_ready,
        local_product_count=len(products),
        local_transaction_count=len(transactions),
        dashboard_response=dashboard_response,
    )
    render_navigation(st, state)

    render_hero(
        st,
        eyebrow="Pengaturan",
        title="Preferensi Bisnis",
        description="Atur preferensi tampilan dan pengalaman aplikasi.",
    )

    if profile_ready:
        render_business_header(st, preferences)

    with st.form("preferences_form"):
        business_name = st.text_input(
            "Nama Bisnis",
            value=str(st.session_state.get("business_name", "")),
            placeholder="Contoh: Kedai Kopi Nusantara",
        )
        owner_name = st.text_input(
            "Nama Pemilik",
            value=str(st.session_state.get("owner_name", "")),
            placeholder="Contoh: Ibu Sari",
        )
        business_type = st.text_input(
            "Jenis Usaha",
            value=str(st.session_state.get("business_type", "")),
            placeholder="Contoh: Kuliner, Retail, Jasa",
        )
        currency = st.selectbox(
            "Mata Uang",
            ["IDR", "USD"],
            index=0 if st.session_state.get("currency", "IDR") == "IDR" else 1,
        )
        timezone_options = ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"]
        current_timezone = str(st.session_state.get("timezone", "Asia/Jakarta"))
        timezone_index = timezone_options.index(current_timezone) if current_timezone in timezone_options else 0
        timezone = st.selectbox(
            "Zona Waktu",
            timezone_options,
            index=timezone_index,
        )
        language = st.selectbox("Bahasa", ["Bahasa Indonesia"])
        submitted = st.form_submit_button("Simpan Preferensi", type="primary")

    if submitted:
        st.session_state["business_name"] = business_name.strip()
        st.session_state["owner_name"] = owner_name.strip()
        st.session_state["business_type"] = business_type.strip()
        st.session_state["currency"] = currency
        st.session_state["timezone"] = timezone
        st.session_state["language"] = language
        st.success("Preferensi tersimpan.")

    with st.expander("Lanjutan"):
        st.caption("Bagian ini hanya untuk pengelola aplikasi.")
        api_base_url = st.text_input(
            "Alamat Layanan",
            value=str(st.session_state.get("api_base_url", DEFAULT_API_BASE_URL)),
        )
        access_key = st.text_input(
            "Kunci Akses Data Bisnis",
            value=str(st.session_state.get("business_id", "")),
            type="password",
        )
        default_product_key = st.text_input(
            "Kunci Produk Default",
            value=str(st.session_state.get("default_product_id", "")),
            type="password",
        )
        data_limit = st.number_input(
            "Batas Data",
            min_value=1,
            max_value=10_000,
            value=int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)),
            step=100,
        )

        if st.button("Simpan Pengaturan Lanjutan"):
            st.session_state["api_base_url"] = api_base_url.strip().rstrip("/")
            st.session_state["business_id"] = access_key.strip()
            st.session_state["default_product_id"] = default_product_key.strip()
            st.session_state["dashboard_limit"] = int(data_limit)
            if access_key and not is_valid_uuid(access_key):
                st.warning("Kunci akses belum valid.")
            else:
                st.success("Pengaturan lanjutan tersimpan.")
                st.rerun()

        if st.button("Periksa Koneksi Layanan"):
            response = get_api_client_from_session_state(st.session_state).health_check()
            if response.get("success"):
                st.success("Layanan terhubung.")
            else:
                st.error("Layanan belum terhubung.")


def _get_streamlit() -> Any:
    """Import Streamlit."""

    import streamlit as st

    return st


if __name__ == "__main__":
    render_page()
