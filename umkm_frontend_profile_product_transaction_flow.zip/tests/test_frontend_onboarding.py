from __future__ import annotations

from app.frontend.onboarding import (
    build_onboarding_state,
    get_current_step_number,
    is_valid_uuid,
)


VALID_UUID = "11111111-1111-4111-8111-111111111111"


def test_profile_missing_stops_at_profile() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=False,
    )
    assert state.business_profile_ready is False
    assert state.next_step == "business_profile"
    assert get_current_step_number(state) == 1


def test_profile_ready_goes_to_products_without_backend() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=True,
    )
    assert state.next_step == "products"
    assert state.has_products is False
    assert get_current_step_number(state) == 2


def test_local_product_goes_to_first_transaction() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=True,
        local_product_count=1,
    )
    assert state.next_step == "first_transaction"
    assert state.has_products is True
    assert get_current_step_number(state) == 3


def test_local_transaction_opens_dashboard() -> None:
    state = build_onboarding_state(
        business_id="",
        business_profile_ready=True,
        local_product_count=1,
        local_transaction_count=1,
    )
    assert state.dashboard_ready is True
    assert state.operational_dashboard_ready is False
    assert state.next_step == "dashboard"
    assert get_current_step_number(state) == 4


def test_valid_uuid_detection() -> None:
    assert is_valid_uuid(VALID_UUID) is True
    assert is_valid_uuid("bukan-kunci-valid") is False


def test_backend_dashboard_ready_state() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 3, "total_revenue": 100000},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        business_profile_ready=True,
        dashboard_response=response,
    )
    assert state.dashboard_ready is True
    assert state.operational_dashboard_ready is True
    assert state.next_step == "dashboard"
    assert state.completion_percent == 100
