from __future__ import annotations

from app.frontend.session import (
    add_local_product,
    add_local_transaction,
    build_business_preferences,
    ensure_frontend_session,
    get_local_products,
    get_local_transactions,
    has_local_business_profile,
    save_business_profile,
)


def test_frontend_session_defaults() -> None:
    session_state = {}
    ensure_frontend_session(session_state)
    assert session_state["currency"] == "IDR"
    assert session_state["timezone"] == "Asia/Jakarta"


def test_save_business_profile_sets_active_profile() -> None:
    session_state = {}
    save_business_profile(
        session_state,
        {
            "business_name": "Kedai Kopi",
            "owner_name": "Sari",
            "business_type": "Kuliner",
            "currency": "IDR",
            "timezone": "Asia/Jakarta",
            "language": "Bahasa Indonesia",
        },
    )
    assert has_local_business_profile(session_state) is True
    preferences = build_business_preferences(session_state)
    assert preferences["business_name"] == "Kedai Kopi"


def test_add_local_product() -> None:
    session_state = {}
    add_local_product(
        session_state,
        {
            "nama_produk": "Kopi Susu",
            "harga_jual": 18000,
            "harga_modal": 10000,
            "stok_awal": 20,
            "satuan": "cup",
            "kategori": "Minuman",
        },
    )
    products = get_local_products(session_state)
    assert len(products) == 1
    assert products[0]["nama_produk"] == "Kopi Susu"


def test_add_local_transaction() -> None:
    session_state = {}
    add_local_transaction(
        session_state,
        {
            "nama_produk": "Kopi Susu",
            "jumlah": 2,
            "harga_jual": 18000,
            "metode_pembayaran": "QRIS",
            "catatan": "Tes",
        },
    )
    transactions = get_local_transactions(session_state)
    assert len(transactions) == 1
    assert transactions[0]["total"] == 36000
