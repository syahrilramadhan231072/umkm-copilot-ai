"""UMKM Copilot AI SaaS welcome and onboarding home page."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_API_BASE_URL, DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_hero, render_onboarding_progress, switch_page


def render_app() -> None:
    """Render welcome and onboarding gate."""

    st = _get_streamlit()
    st.set_page_config(page_title="UMKM Copilot AI", page_icon="🤖", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    render_hero(
        st,
        eyebrow="Welcome",
        title="Welcome to UMKM Copilot AI",
        description="Let's set up your business in just a few minutes.",
    )

    business_id = str(st.session_state.get("business_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    client = get_api_client_from_session_state(st.session_state)

    with st.sidebar:
        st.subheader("Active Setup")
        st.write(f"API: `{st.session_state.get('api_base_url', DEFAULT_API_BASE_URL)}`")
        st.write(f"Business ID: `{business_id or 'not set'}`")

    dashboard_response = None
    if is_valid_uuid(business_id):
        with st.spinner("Checking your business setup..."):
            dashboard_response = client.get_dashboard(business_id=business_id, limit=limit)

    state = build_onboarding_state(business_id=business_id, dashboard_response=dashboard_response)
    render_onboarding_progress(st, state)

    col_primary, col_secondary = st.columns(2)
    with col_primary:
        if not state.business_id_valid:
            if st.button("Get Started", type="primary"):
                switch_page(st, "pages/Settings.py")
            st.caption("Mulai dari Settings untuk mengatur backend dan Business ID.")
        elif not state.has_products:
            if st.button("Continue Setup", type="primary"):
                switch_page(st, "pages/Transactions.py")
            st.caption("Produk belum terdeteksi. Siapkan produk di backend lalu catat transaksi pertama.")
        elif not state.has_transactions:
            if st.button("Record First Transaction", type="primary"):
                switch_page(st, "pages/Transactions.py")
            st.caption("Catat penjualan pertama untuk membuka Dashboard.")
        else:
            if st.button("Open Dashboard", type="primary"):
                switch_page(st, "pages/Dashboard.py")
            st.caption("Dashboard dan AI Copilot sudah siap.")

    with col_secondary:
        if st.button("Check API Health"):
            with st.spinner("Checking backend..."):
                response = client.health_check()
            if response.get("success"):
                st.success("Backend connected.")
            else:
                st.error(_error_message(response))

    st.divider()
    _render_lifecycle(st, state)


def _render_lifecycle(st: Any, state: Any) -> None:
    cards = [
        ("Business Profile", "Aktifkan Business ID valid.", state.has_business_profile),
        ("Products", "Siapkan produk agar transaksi punya konteks.", state.has_products),
        ("First Transaction", "Catat penjualan pertama untuk membuka analytics.", state.has_transactions),
        ("AI Copilot", "Gunakan AI setelah data bisnis tersedia.", state.ai_ready),
    ]
    columns = st.columns(4)
    for index, (title, body, ready) in enumerate(cards):
        with columns[index]:
            st.markdown(f"### {title}")
            st.caption(body)
            st.success("Ready") if ready else st.info("Pending")


def _error_message(response: dict[str, Any]) -> str:
    error = response.get("error")
    if isinstance(error, dict):
        return str(error.get("message", "Request failed."))
    return "Request failed."


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_app()
