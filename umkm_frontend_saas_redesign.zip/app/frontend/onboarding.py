"""Onboarding readiness helpers for the Streamlit frontend."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping
from uuid import UUID


@dataclass(frozen=True)
class OnboardingState:
    """Business lifecycle readiness state."""

    business_id: str
    business_id_valid: bool
    backend_reachable: bool
    has_business_profile: bool
    has_products: bool
    has_transactions: bool
    dashboard_ready: bool
    marketing_ready: bool
    insights_ready: bool
    ai_ready: bool
    next_step: str
    completion_percent: int
    error_message: str | None = None


def is_valid_uuid(value: str) -> bool:
    """Return True when value is a valid UUID."""

    if not isinstance(value, str) or not value.strip():
        return False
    try:
        UUID(value.strip())
    except (TypeError, ValueError, AttributeError):
        return False
    return True


def build_onboarding_state(
    *,
    business_id: str,
    dashboard_response: Mapping[str, Any] | None = None,
) -> OnboardingState:
    """Build onboarding state from session business ID and dashboard response."""

    if not is_valid_uuid(business_id):
        return OnboardingState(
            business_id=business_id,
            business_id_valid=False,
            backend_reachable=False,
            has_business_profile=False,
            has_products=False,
            has_transactions=False,
            dashboard_ready=False,
            marketing_ready=False,
            insights_ready=False,
            ai_ready=False,
            next_step="settings",
            completion_percent=0,
            error_message="Business ID belum valid.",
        )

    if not dashboard_response or not dashboard_response.get("success"):
        return OnboardingState(
            business_id=business_id,
            business_id_valid=True,
            backend_reachable=False,
            has_business_profile=True,
            has_products=False,
            has_transactions=False,
            dashboard_ready=False,
            marketing_ready=False,
            insights_ready=False,
            ai_ready=False,
            next_step="connect_backend",
            completion_percent=20,
            error_message=_error_message(dashboard_response or {}),
        )

    data = _mapping(dashboard_response.get("data"))
    has_products = _has_products(data)
    has_transactions = _has_transactions(data)
    dashboard_ready = has_products and has_transactions
    completed = sum([True, has_products, has_transactions])
    next_step = "dashboard" if dashboard_ready else "first_transaction" if has_products else "products"

    return OnboardingState(
        business_id=business_id,
        business_id_valid=True,
        backend_reachable=True,
        has_business_profile=True,
        has_products=has_products,
        has_transactions=has_transactions,
        dashboard_ready=dashboard_ready,
        marketing_ready=has_products,
        insights_ready=has_transactions,
        ai_ready=dashboard_ready,
        next_step=next_step,
        completion_percent=int((completed / 3) * 100),
    )


def get_setup_steps(state: OnboardingState) -> list[dict[str, Any]]:
    """Return setup progress rows."""

    return [
        {"name": "Business Profile", "complete": state.has_business_profile},
        {"name": "Products", "complete": state.has_products},
        {"name": "First Transaction", "complete": state.has_transactions},
        {"name": "Dashboard", "complete": state.dashboard_ready},
    ]


def _has_products(data: Mapping[str, Any]) -> bool:
    product_summary = _mapping(data.get("product_summary"))
    inventory_summary = _mapping(data.get("inventory_summary"))
    return (
        _positive_in_mapping(product_summary, ("product", "active", "count", "total"))
        or _positive_in_mapping(inventory_summary, ("product", "stock", "item", "count", "total"))
        or bool(data.get("top_products_by_revenue"))
        or bool(data.get("top_products_by_quantity"))
    )


def _has_transactions(data: Mapping[str, Any]) -> bool:
    sales_summary = _mapping(data.get("sales_summary"))
    return (
        _positive_in_mapping(sales_summary, ("transaction", "revenue", "sales", "quantity", "order", "total"))
        or _positive_in_list(data.get("top_products_by_revenue"))
        or _positive_in_list(data.get("top_products_by_quantity"))
    )


def _positive_in_mapping(data: Mapping[str, Any], keywords: tuple[str, ...]) -> bool:
    for key, value in data.items():
        key_text = str(key).lower()
        if any(word in key_text for word in keywords):
            number = _decimal(value)
            if number is not None and number > 0:
                return True
        if isinstance(value, Mapping) and _positive_in_mapping(value, keywords):
            return True
    return False


def _positive_in_list(value: Any) -> bool:
    if not isinstance(value, list):
        return False
    for row in value:
        if isinstance(row, Mapping):
            for metric in row.values():
                number = _decimal(metric)
                if number is not None and number > 0:
                    return True
    return False


def _decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _mapping(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])
    return "Backend belum dapat memuat dashboard."
