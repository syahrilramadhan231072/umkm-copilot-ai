"""Reusable Streamlit UI components for SaaS-style frontend."""

from __future__ import annotations

from typing import Any

from app.frontend.onboarding import OnboardingState, get_setup_steps


def render_hero(st: Any, *, eyebrow: str, title: str, description: str) -> None:
    """Render SaaS hero block."""

    st.markdown(
        f"""
        <section class="umkm-page-hero">
          <p class="umkm-page-hero__eyebrow">{eyebrow}</p>
          <h1 class="umkm-page-hero__title">{title}</h1>
          <p class="umkm-page-hero__description">{description}</p>
        </section>
        """,
        unsafe_allow_html=True,
    )


def render_onboarding_progress(st: Any, state: OnboardingState) -> None:
    """Render onboarding progress."""

    st.progress(state.completion_percent, text=f"{state.completion_percent}% complete")
    columns = st.columns(4)
    for index, step in enumerate(get_setup_steps(state)):
        with columns[index]:
            icon = "[x]" if bool(step["complete"]) else "[ ]"
            st.markdown(f"**{icon} {step['name']}**")


def render_locked_page(
    st: Any,
    *,
    message: str,
    state: OnboardingState,
    next_action_label: str,
    next_page: str,
) -> None:
    """Render locked page guidance."""

    st.warning(message)
    render_onboarding_progress(st, state)
    if st.button(next_action_label, type="primary"):
        switch_page(st, next_page)


def switch_page(st: Any, page_path: str) -> None:
    """Switch page when Streamlit supports it."""

    if hasattr(st, "switch_page"):
        st.switch_page(page_path)
    else:
        st.info(f"Buka halaman `{page_path}` melalui sidebar.")
