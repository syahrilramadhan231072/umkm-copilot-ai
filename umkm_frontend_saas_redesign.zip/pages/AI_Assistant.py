"""AI Assistant page unlocked after dashboard data exists."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page

PAGE_NAME = "ai_assistant"


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit(); st.set_page_config(page_title="AI Assistant", page_icon="🤖", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME); ensure_frontend_session(st.session_state)
    st.session_state.setdefault("chat_messages", [])
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state["business_id"]); session_id = str(st.session_state["session_id"])
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    if not is_valid_uuid(business_id):
        render_locked_page(st, message="AI membutuhkan Business ID valid dan konteks bisnis.", state=build_onboarding_state(business_id=business_id), next_action_label="Open Settings", next_page="pages/Settings.py"); return
    with st.spinner("Checking AI readiness..."):
        state = build_onboarding_state(business_id=business_id, dashboard_response=client.get_dashboard(business_id, limit))
    if not state.ai_ready:
        render_locked_page(st, message="Lengkapi produk dan transaksi pertama agar AI memiliki konteks bisnis.", state=state, next_action_label="Continue Setup", next_page="pages/Transactions.py"); return
    st.subheader("Ask Your Business Copilot")
    st.caption("Examples: `Which product sells best?` · `Which products should I restock?` · `What should I promote this week?`")
    with st.sidebar:
        route = st.selectbox("Route", ["auto", "business", "transaction", "marketing", "insight", "export"])
    for message in st.session_state["chat_messages"]:
        with st.chat_message(message["role"]): st.write(message["content"])
    user_input = st.chat_input("Tanyakan sesuatu tentang bisnis Anda...")
    if user_input:
        st.session_state["chat_messages"].append({"role": "user", "content": user_input})
        request = build_route_payload(business_id=business_id, session_id=session_id, user_input=user_input, explicit_route=None if route == "auto" else str(route))
        with st.spinner("AI Copilot is thinking..."):
            response = client.route(**request)
        st.session_state["chat_messages"].append({"role": "assistant", "content": extract_assistant_text(response)})
        st.rerun()
    if st.button("Clear Chat"):
        st.session_state["chat_messages"] = []; st.rerun()


def build_route_payload(*, business_id: str, session_id: str, user_input: str, explicit_route: str | None = None) -> dict[str, Any]:
    return {"user_input": user_input.strip(), "payload": {"business_id": business_id, "session_id": session_id, "user_message": user_input.strip()}, "explicit_route": explicit_route}


def extract_assistant_text(response: Mapping[str, Any]) -> str:
    if not response.get("success"):
        error = response.get("error"); return f"Maaf, terjadi kendala: {error.get('message', 'Unknown error')}" if isinstance(error, Mapping) else "Maaf, terjadi kendala."
    data = response.get("data", {})
    if isinstance(data, Mapping):
        return f"Permintaan berhasil diproses melalui route {data.get('route')}."
    return "Permintaan berhasil diproses."


def _get_streamlit() -> Any:
    import streamlit as st
    return st

if __name__ == "__main__":
    render_page()
