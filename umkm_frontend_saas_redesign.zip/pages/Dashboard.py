"""Production SaaS Dashboard page using only client.get_dashboard()."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Mapping, Sequence

from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page, switch_page


PAGE_NAME = "dashboard"
CURRENCY_PREFIX = "Rp"


def render_page(api_client: Any | None = None) -> None:
    """Render Dashboard with one backend request."""

    st = _get_streamlit()
    st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)

    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    with st.sidebar:
        st.subheader("Dashboard Context")
        st.caption(f"Business ID: `{_mask(business_id) if business_id else 'not set'}`")
        st.session_state["dashboard_limit"] = int(st.number_input("Data Limit", 1, 10000, limit, 100))
        if st.button("Open Settings"):
            switch_page(st, "pages/Settings.py")

    if not is_valid_uuid(business_id):
        state = build_onboarding_state(business_id=business_id)
        render_locked_page(
            st,
            message="Dashboard membutuhkan Business ID UUID yang valid.",
            state=state,
            next_action_label="Open Settings",
            next_page="pages/Settings.py",
        )
        return

    with st.spinner("Loading dashboard..."):
        response = client.get_dashboard(business_id=business_id, limit=limit)

    if not response.get("success"):
        st.error(_error_message(response))
        return

    state = build_onboarding_state(business_id=business_id, dashboard_response=response)
    if not state.dashboard_ready:
        render_locked_page(
            st,
            message="Dashboard belum siap. Lengkapi produk dan transaksi pertama agar dashboard tidak kosong.",
            state=state,
            next_action_label="Continue Setup",
            next_page="pages/Transactions.py",
        )
        return

    data = _mapping(response.get("data"))
    _render_kpis(st, _list(data, "kpi_cards"))
    _render_alerts(st, _list(data, "alerts"))

    sales_tab, inventory_tab, product_tab, customer_tab, top_tab = st.tabs(
        ["Sales", "Inventory", "Products", "Customers", "Top Products"]
    )
    with sales_tab:
        _render_summary(st, "Sales Summary", _mapping(data.get("sales_summary")))
    with inventory_tab:
        _render_summary(st, "Inventory Summary", _mapping(data.get("inventory_summary")))
    with product_tab:
        _render_summary(st, "Product Summary", _mapping(data.get("product_summary")))
    with customer_tab:
        _render_summary(st, "Customer Summary", _mapping(data.get("customer_summary")))
    with top_tab:
        col_revenue, col_quantity = st.columns(2)
        with col_revenue:
            _render_ranking(st, "Top Revenue Products", _list(data, "top_products_by_revenue"), "Revenue", ("revenue", "total_revenue", "sales_revenue", "value"))
        with col_quantity:
            _render_ranking(st, "Top Quantity Products", _list(data, "top_products_by_quantity"), "Quantity", ("quantity", "total_quantity", "quantity_sold", "sold", "value"))


def extract_dashboard_cards(response: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Compatibility helper for tests."""

    return _list(_mapping(response.get("data")), "kpi_cards") if response.get("success") else []


def extract_alerts(response: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Compatibility helper for tests."""

    return _list(_mapping(response.get("data")), "alerts") if response.get("success") else []


def get_error_message(response: Mapping[str, Any]) -> str:
    """Compatibility helper for tests."""

    return _error_message(response)


def _render_kpis(st: Any, cards: list[dict[str, Any]]) -> None:
    st.subheader("Business KPI")
    if not cards:
        st.info("KPI belum tersedia.")
        return
    columns = st.columns(min(len(cards), 4))
    for index, card in enumerate(cards):
        label = str(card.get("label") or card.get("title") or card.get("key") or "KPI")
        value = _format_value(card.get("value"), value_type=str(card.get("type") or label))
        delta = card.get("delta") or card.get("change") or card.get("trend")
        with columns[index % len(columns)]:
            st.metric(label=label, value=value, delta=None if delta is None else str(delta))


def _render_alerts(st: Any, alerts: list[dict[str, Any]]) -> None:
    if not alerts:
        return
    st.subheader("Alerts")
    for alert in alerts:
        message = str(alert.get("message") or alert.get("title") or alert)
        severity = str(alert.get("severity") or alert.get("level") or "info").lower()
        if severity in {"danger", "error", "critical", "high"}:
            st.error(message)
        elif severity in {"warning", "warn", "medium"}:
            st.warning(message)
        elif severity in {"success", "ok", "low"}:
            st.success(message)
        else:
            st.info(message)


def _render_summary(st: Any, title: str, summary: dict[str, Any]) -> None:
    st.subheader(title)
    if not summary:
        st.info("Data belum tersedia.")
        return
    scalars = [(str(k), v) for k, v in summary.items() if _scalar(v)]
    if scalars:
        columns = st.columns(min(len(scalars), 4))
        for index, (key, value) in enumerate(scalars):
            with columns[index % len(columns)]:
                st.metric(_human(key), _format_value(value, value_type=key))
    nested = _nested_records(summary)
    if nested:
        with st.expander("Details"):
            st.dataframe(nested, use_container_width=True, hide_index=True)


def _render_ranking(st: Any, title: str, rows: list[dict[str, Any]], value_label: str, keys: Sequence[str]) -> None:
    st.subheader(title)
    if not rows:
        st.info("Belum tersedia.")
        return
    records = [_product_row(row, value_label, keys) for row in rows]
    st.dataframe(records, use_container_width=True, hide_index=True)
    try:
        import pandas as pd
        frame = pd.DataFrame(records)
        frame[value_label] = frame[value_label].map(lambda v: _float(v) or 0.0)
        st.bar_chart(frame.set_index("Product")[[value_label]], use_container_width=True)
    except Exception:
        pass


def _product_row(row: Mapping[str, Any], value_label: str, keys: Sequence[str]) -> dict[str, Any]:
    return {
        "Product": str(row.get("product_name") or row.get("name") or row.get("product") or row.get("id") or "Unknown"),
        value_label: _first(row, keys) or 0,
        "Category": str(row.get("category") or "-"),
        "Product ID": str(row.get("product_id") or row.get("id") or "-"),
    }


def _nested_records(summary: Mapping[str, Any]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for key, value in summary.items():
        if isinstance(value, Mapping):
            row = {"section": _human(str(key))}
            row.update({str(k): v for k, v in value.items()})
            records.append(row)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, Mapping):
                    row = {"section": _human(str(key))}
                    row.update({str(k): v for k, v in item.items()})
                    records.append(row)
    return records


def _format_value(value: Any, *, value_type: str = "") -> str:
    if value is None:
        return "-"
    if _currency_key(value_type):
        number = _decimal(value)
        return str(value) if number is None else f"{CURRENCY_PREFIX}{int(number):,}".replace(",", ".")
    number = _decimal(value)
    if number is not None:
        return f"{int(number):,}".replace(",", ".") if number == number.to_integral() else str(float(number))
    return str(value)


def _currency_key(key: str) -> bool:
    return any(word in key.lower() for word in ("revenue", "sales", "amount", "price", "cost", "value", "idr", "rupiah"))


def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error")
    return str(error.get("message")) if isinstance(error, Mapping) and error.get("message") else "Request gagal."


def _list(data: Mapping[str, Any], key: str) -> list[dict[str, Any]]:
    value = data.get(key)
    return [dict(x) if isinstance(x, Mapping) else {"value": x} for x in value] if isinstance(value, list) else []


def _mapping(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool, Decimal))


def _decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _float(value: Any) -> float | None:
    number = _decimal(value)
    return float(number) if number is not None else None


def _first(data: Mapping[str, Any], keys: Sequence[str]) -> Any | None:
    for key in keys:
        if key in data:
            return data[key]
    return None


def _human(key: str) -> str:
    return key.replace("_", " ").replace("-", " ").title()


def _mask(value: str) -> str:
    return value if len(value) <= 12 else f"{value[:8]}...{value[-4:]}"


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
