"""Export reports after dashboard is ready."""

from __future__ import annotations
import json
from typing import Any, Mapping
from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page
PAGE_NAME = "export"

def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit(); st.set_page_config(page_title="Export", page_icon="⬇️", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME); ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state["business_id"]); session_id = str(st.session_state["session_id"]); limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    if not is_valid_uuid(business_id):
        render_locked_page(st, message="Export membutuhkan Business ID valid.", state=build_onboarding_state(business_id=business_id), next_action_label="Open Settings", next_page="pages/Settings.py"); return
    with st.spinner("Checking export readiness..."):
        state = build_onboarding_state(business_id=business_id, dashboard_response=client.get_dashboard(business_id, limit))
    if not state.dashboard_ready:
        render_locked_page(st, message="Lengkapi setup agar laporan tidak kosong.", state=state, next_action_label="Continue Setup", next_page="pages/Transactions.py"); return
    st.subheader("Export Business Reports")
    export_type = st.selectbox("Export Type", ["dashboard", "sales_summary", "inventory_summary"]); export_format = st.selectbox("Format", ["json", "csv"]); report_limit = st.number_input("Limit", 1, 10000, limit, 100)
    if st.button("Generate Export", type="primary"):
        payload = {"business_id": business_id, "export_type": export_type, "export_format": export_format, "limit": int(report_limit), "session_id": session_id}
        response = client.export_dashboard(payload) if export_type == "dashboard" else client.export_sales_summary(payload) if export_type == "sales_summary" else client.export_inventory_summary(payload)
        _render_download(st, response, export_format=str(export_format))
    with st.expander("Structured Export"):
        prefix = st.text_input("Filename Prefix", value="structured_export"); structured_format = st.selectbox("Structured Format", ["json", "csv"]); text = st.text_area("Data JSON", value='[{"name": "Sample Product", "value": 100}]')
        if st.button("Export Structured Data"):
            try:
                payload = {"data_to_export": json.loads(text), "export_format": structured_format, "filename_prefix": prefix}
                _render_download(st, client.export_structured_data(payload), export_format=str(structured_format))
            except Exception as exc: st.error(str(exc))

def _render_download(st: Any, response: Mapping[str, Any], *, export_format: str) -> None:
    if not response.get("success"):
        st.error(_error_message(response)); return
    data = response.get("data", {}); export_file = data.get("export") if isinstance(data, Mapping) and isinstance(data.get("export"), Mapping) else data if isinstance(data, Mapping) else {}
    st.success("Export ready."); st.download_button("Download Export", data=str(export_file.get("content", "")), file_name=str(export_file.get("filename", f"export.{export_format}")), mime=str(export_file.get("content_type") or ("text/csv" if export_format == "csv" else "application/json")))

def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error"); return str(error.get("message")) if isinstance(error, Mapping) and error.get("message") else "Export failed."

def _get_streamlit() -> Any:
    import streamlit as st
    return st
if __name__ == "__main__": render_page()
