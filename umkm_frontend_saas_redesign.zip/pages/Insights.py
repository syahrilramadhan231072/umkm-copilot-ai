"""Insights workspace unlocked after transactions exist."""

from __future__ import annotations
from typing import Any, Mapping
from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page
PAGE_NAME = "insights"

def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit(); st.set_page_config(page_title="Insights", page_icon="💡", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME); ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state["business_id"]); session_id = str(st.session_state["session_id"]); limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    if not is_valid_uuid(business_id):
        render_locked_page(st, message="Insights membutuhkan Business ID valid.", state=build_onboarding_state(business_id=business_id), next_action_label="Open Settings", next_page="pages/Settings.py"); return
    with st.spinner("Checking insight readiness..."):
        state = build_onboarding_state(business_id=business_id, dashboard_response=client.get_dashboard(business_id, limit))
    if not state.insights_ready:
        render_locked_page(st, message="Catat transaksi pertama agar insight berbasis data dapat ditampilkan.", state=state, next_action_label="Record First Transaction", next_page="pages/Transactions.py"); return
    context_tab, review_tab, create_tab = st.tabs(["Context", "Review", "Save Insight"])
    with context_tab:
        if st.button("Load Insight Context", type="primary"):
            _render_response(st, client.get_insight_context({"business_id": business_id, "limit": limit, "session_id": session_id}))
    with review_tab:
        keyword = st.text_input("Search Keyword"); category = st.text_input("Insight Category")
        if st.button("Review Insights"):
            _render_response(st, client.get_insight_review(business_id, keyword or None, category or None, limit))
    with create_tab:
        with st.form("create_insight_form"):
            title = st.text_input("Title"); category_input = st.text_input("Category", value="general"); priority = st.selectbox("Priority", ["low", "medium", "high"]); content = st.text_area("Content"); submitted = st.form_submit_button("Save Insight")
        if submitted:
            payload = {"business_id": business_id, "insight_data": {"title": title, "insight_category": category_input, "content": content, "priority": priority}, "session_id": session_id}
            _render_response(st, client.create_insight(payload))

def _render_response(st: Any, response: Mapping[str, Any]) -> None:
    if not response.get("success"):
        st.error(_error_message(response)); return
    st.success("Request successful."); data = response.get("data")
    if isinstance(data, list): st.dataframe(data, use_container_width=True, hide_index=True)
    elif isinstance(data, Mapping): st.dataframe([{"Metric": k, "Value": v} for k, v in data.items()], use_container_width=True, hide_index=True)

def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error"); return str(error.get("message")) if isinstance(error, Mapping) and error.get("message") else "Request failed."

def _get_streamlit() -> Any:
    import streamlit as st
    return st
if __name__ == "__main__": render_page()
