"""Marketing workspace unlocked after products exist."""

from __future__ import annotations
from typing import Any, Mapping
from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page
PAGE_NAME = "marketing"

def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit(); st.set_page_config(page_title="Marketing", page_icon="📣", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME); ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state["business_id"]); session_id = str(st.session_state["session_id"]); limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    if not is_valid_uuid(business_id):
        render_locked_page(st, message="Marketing membutuhkan Business ID valid.", state=build_onboarding_state(business_id=business_id), next_action_label="Open Settings", next_page="pages/Settings.py"); return
    with st.spinner("Checking marketing readiness..."):
        state = build_onboarding_state(business_id=business_id, dashboard_response=client.get_dashboard(business_id, limit))
    if not state.marketing_ready:
        render_locked_page(st, message="Tambahkan produk agar marketing context relevan.", state=state, next_action_label="Continue Setup", next_page="pages/Transactions.py"); return
    context_tab, record_tab, history_tab = st.tabs(["Product Context", "Save Campaign", "History"])
    with context_tab:
        product_id = st.text_input("Product ID")
        if st.button("Build Marketing Context", type="primary"):
            _render_response(st, client.get_marketing_context({"product_id": product_id, "business_id": business_id, "session_id": session_id}))
    with record_tab:
        with st.form("marketing_record_form"):
            platform = st.text_input("Platform", value="Instagram"); record_product_id = st.text_input("Product ID"); campaign = st.text_input("Campaign Name"); caption = st.text_area("Caption"); submitted = st.form_submit_button("Save Marketing Record")
        if submitted:
            payload = {"business_id": business_id, "marketing_data": {"platform": platform, "caption": caption, "campaign_name": campaign or None, "product_id": record_product_id or None}, "session_id": session_id}
            _render_response(st, client.create_marketing_record(payload))
    with history_tab:
        keyword = st.text_input("Keyword"); history_limit = st.number_input("History Limit", 1, 1000, 100, 10)
        if st.button("Load Marketing History"):
            _render_response(st, client.get_marketing_history(business_id, keyword or None, int(history_limit)))

def _render_response(st: Any, response: Mapping[str, Any]) -> None:
    if not response.get("success"):
        st.error(_error_message(response)); return
    st.success("Request successful."); data = response.get("data")
    if isinstance(data, list): st.dataframe(data, use_container_width=True, hide_index=True)
    elif isinstance(data, Mapping): st.dataframe([{"Metric": k, "Value": v} for k, v in data.items()], use_container_width=True, hide_index=True)

def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error"); return str(error.get("message")) if isinstance(error, Mapping) and error.get("message") else "Request failed."

def _get_streamlit() -> Any:
    import streamlit as st
    return st
if __name__ == "__main__": render_page()
