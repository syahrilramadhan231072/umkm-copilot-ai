"""Guided first transaction page."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_frontend_assets
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_page

PAGE_NAME = "transactions"


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="Transactions", page_icon="🧾", layout="wide")
    load_frontend_assets(st, page_name=PAGE_NAME)
    ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state["business_id"])
    session_id = str(st.session_state["session_id"])
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    if not is_valid_uuid(business_id):
        state = build_onboarding_state(business_id=business_id)
        render_locked_page(st, message="Atur Business ID valid sebelum mencatat transaksi.", state=state, next_action_label="Open Settings", next_page="pages/Settings.py")
        return

    with st.spinner("Checking setup..."):
        state = build_onboarding_state(business_id=business_id, dashboard_response=client.get_dashboard(business_id, limit))
    if not state.has_products:
        st.info("Produk belum terdeteksi. Jika produk sudah ada di backend, masukkan Product ID valid untuk mencatat transaksi.")

    st.subheader("Record First Sale")
    with st.form("transaction_form"):
        product_id = st.text_input("Product ID")
        quantity = st.number_input("Quantity", min_value=1, value=1, step=1)
        payment_method = st.selectbox("Payment Method", ["cash", "qris", "transfer", "credit_card", "other"])
        status = st.selectbox("Status", ["completed", "cancelled", "refunded"])
        notes = st.text_area("Notes", value="First sale from Streamlit")
        submitted = st.form_submit_button("Record Transaction", type="primary")
    if submitted:
        payload = build_transaction_payload(business_id=business_id, product_id=product_id, quantity=int(quantity), payment_method=str(payment_method), status=str(status), notes=notes, session_id=session_id)
        with st.spinner("Recording transaction..."):
            response = client.record_transaction(payload)
        st.success("Transaction recorded.") if response.get("success") else st.error(_error_message(response))

    if st.button("Check Transaction Summary"):
        with st.spinner("Loading summary..."):
            response = client.get_transaction_summary(business_id, limit)
        _render_response(st, response)


def build_transaction_payload(*, business_id: str, product_id: str, quantity: int, payment_method: str, status: str, notes: str | None = None, session_id: str | None = None) -> dict[str, Any]:
    if not business_id.strip() or not product_id.strip() or quantity <= 0:
        raise ValueError("business_id, product_id, and positive quantity are required.")
    return {"business_id": business_id.strip(), "product_id": product_id.strip(), "quantity": quantity, "payment_method": payment_method, "status": status, "notes": notes.strip() if notes else None, "session_id": session_id}


def _render_response(st: Any, response: Mapping[str, Any]) -> None:
    if not response.get("success"):
        st.error(_error_message(response)); return
    data = response.get("data")
    if isinstance(data, Mapping):
        st.dataframe([{"Metric": k, "Value": v} for k, v in data.items()], use_container_width=True, hide_index=True)
    else:
        st.success("Request successful.")


def _error_message(response: Mapping[str, Any]) -> str:
    error = response.get("error")
    return str(error.get("message")) if isinstance(error, Mapping) and error.get("message") else "Request failed."


def _get_streamlit() -> Any:
    import streamlit as st
    return st

if __name__ == "__main__":
    render_page()
