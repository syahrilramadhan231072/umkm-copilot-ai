from __future__ import annotations
from app.frontend.onboarding import build_onboarding_state, get_setup_steps, is_valid_uuid
VALID_UUID = "11111111-1111-4111-8111-111111111111"

def test_invalid_business_id_state() -> None:
    state = build_onboarding_state(business_id="bad")
    assert state.next_step == "settings"
    assert state.dashboard_ready is False

def test_valid_uuid_detection() -> None:
    assert is_valid_uuid(VALID_UUID) is True
    assert is_valid_uuid("abc") is False

def test_ready_state() -> None:
    response = {"success": True, "data": {"product_summary": {"total_products": 3}, "sales_summary": {"total_transactions": 5}}, "error": None}
    state = build_onboarding_state(business_id=VALID_UUID, dashboard_response=response)
    assert state.dashboard_ready is True
    assert state.next_step == "dashboard"
    assert state.completion_percent == 100

def test_steps() -> None:
    assert len(get_setup_steps(build_onboarding_state(business_id="bad"))) == 4
