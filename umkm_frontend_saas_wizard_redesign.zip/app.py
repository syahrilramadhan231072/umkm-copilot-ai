"""UMKM Copilot AI SaaS Welcome Page."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_friendly_error, render_hero, render_progress, switch_page


def render_app() -> None:
    """Render welcome and onboarding entry page."""

    st = _get_streamlit()
    st.set_page_config(page_title="UMKM Copilot AI", page_icon="🤖", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    dashboard_response: dict[str, Any] | None = None
    if is_valid_uuid(business_id):
        client = get_api_client_from_session_state(st.session_state)
        with st.spinner("Preparing your workspace..."):
            dashboard_response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))

    state = build_onboarding_state(
        business_id=business_id,
        welcome_seen=bool(st.session_state.get("welcome_seen", False)),
        dashboard_response=dashboard_response,
    )
    render_sidebar(st, state, current_page="Welcome")

    if state.onboarding_complete:
        render_hero(
            st,
            eyebrow="Workspace ready",
            title="Your business copilot is ready",
            description="Your dashboard, assistant, marketing tools, insights, and exports are now available.",
        )
        col_one, col_two = st.columns(2)
        with col_one:
            if st.button("Open Dashboard", type="primary", use_container_width=True):
                switch_page(st, "pages/Dashboard.py")
        with col_two:
            if st.button("Ask AI Assistant", use_container_width=True):
                switch_page(st, "pages/AI_Assistant.py")
        return

    render_hero(
        st,
        eyebrow="Welcome",
        title="Welcome to UMKM Copilot AI",
        description="Let’s set up your business in just a few minutes. We will guide you one step at a time.",
    )
    render_progress(st, state)

    if state.error_message:
        render_friendly_error(st, state.error_message)

    st.markdown("### What you will set up")
    col_one, col_two, col_three = st.columns(3)
    with col_one:
        st.markdown("#### Business Profile")
        st.caption("Basic information about your business.")
    with col_two:
        st.markdown("#### Products")
        st.caption("Your product catalog and stock context.")
    with col_three:
        st.markdown("#### First Sale")
        st.caption("One transaction unlocks useful analytics.")

    if st.button("Get Started", type="primary"):
        st.session_state["welcome_seen"] = True
        switch_page(st, "pages/Business_Profile.py")


def _get_streamlit() -> Any:
    """Import Streamlit lazily."""

    import streamlit as st
    return st


if __name__ == "__main__":
    render_app()
