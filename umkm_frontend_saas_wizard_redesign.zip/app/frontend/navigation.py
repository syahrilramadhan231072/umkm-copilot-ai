"""
Frontend Navigation
===================

Custom sidebar navigation that hides developer-oriented Streamlit page listing
and reveals application modules progressively.
"""

from __future__ import annotations

from typing import Any

from app.frontend.onboarding import OnboardingState
from app.frontend.ui_components import switch_page


ONBOARDING_ITEMS = [
    ("Welcome", "app.py", "welcome"),
    ("Business Profile", "pages/Business_Profile.py", "business_profile"),
    ("Products", "pages/Products.py", "products"),
    ("First Transaction", "pages/First_Transaction.py", "first_transaction"),
    ("Settings", "pages/Settings.py", "settings"),
]

APP_ITEMS = [
    ("Dashboard", "pages/Dashboard.py"),
    ("AI Assistant", "pages/AI_Assistant.py"),
    ("Transactions", "pages/Transactions.py"),
    ("Marketing", "pages/Marketing.py"),
    ("Insights", "pages/Insights.py"),
    ("Export", "pages/Export.py"),
    ("Settings", "pages/Settings.py"),
]

STEP_ORDER = {
    "welcome": 0,
    "business_profile": 1,
    "products": 2,
    "first_transaction": 3,
    "dashboard": 4,
    "settings": 99,
}


def render_sidebar(st: Any, state: OnboardingState, *, current_page: str) -> None:
    """Render custom sidebar navigation."""

    with st.sidebar:
        st.markdown("### UMKM Copilot AI")
        st.caption("Your business copilot")
        st.divider()

        if state.onboarding_complete:
            st.caption("Workspace")
            for label, page in APP_ITEMS:
                if st.button(label, use_container_width=True, disabled=(label == current_page)):
                    switch_page(st, page)
            return

        st.caption("Setup")
        for label, page, step in ONBOARDING_ITEMS:
            if step == "settings":
                if st.button(label, use_container_width=True, disabled=(label == current_page)):
                    switch_page(st, page)
                continue

            if _is_step_unlocked(state, step):
                if st.button(label, use_container_width=True, disabled=(label == current_page)):
                    switch_page(st, page)
            elif step == state.current_step:
                if st.button(label, use_container_width=True, disabled=(label == current_page)):
                    switch_page(st, page)
            else:
                st.caption(f"○ {label}")


def _is_step_unlocked(state: OnboardingState, step: str) -> bool:
    """Return True if onboarding step is accessible."""

    if step == "welcome":
        return True
    if step == "business_profile":
        return state.welcome_seen
    if step == "products":
        return state.has_business_profile
    if step == "first_transaction":
        return state.has_products
    return STEP_ORDER.get(step, 99) <= STEP_ORDER.get(state.current_step, 0)
