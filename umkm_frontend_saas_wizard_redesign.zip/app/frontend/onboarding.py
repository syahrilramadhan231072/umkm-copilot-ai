"""
Frontend Onboarding State
=========================

Business lifecycle readiness helpers.

The frontend reads readiness from backend API responses through
FrontendApiClient. It does not call backend services, repositories, or database.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping
from uuid import UUID


@dataclass(frozen=True)
class OnboardingState:
    """SaaS onboarding readiness state."""

    welcome_seen: bool
    business_id_valid: bool
    backend_reachable: bool
    has_business_profile: bool
    has_products: bool
    has_transactions: bool
    onboarding_complete: bool
    current_step: str
    progress_value: float
    error_message: str | None = None


def build_onboarding_state(
    *,
    business_id: str,
    welcome_seen: bool = False,
    dashboard_response: Mapping[str, Any] | None = None,
) -> OnboardingState:
    """Build onboarding state from session and dashboard response."""

    business_id_valid = is_valid_uuid(business_id)

    if not welcome_seen:
        return OnboardingState(
            welcome_seen=False,
            business_id_valid=business_id_valid,
            backend_reachable=False,
            has_business_profile=False,
            has_products=False,
            has_transactions=False,
            onboarding_complete=False,
            current_step="welcome",
            progress_value=0.0,
        )

    if not business_id_valid:
        return OnboardingState(
            welcome_seen=True,
            business_id_valid=False,
            backend_reachable=False,
            has_business_profile=False,
            has_products=False,
            has_transactions=False,
            onboarding_complete=False,
            current_step="business_profile",
            progress_value=0.25,
            error_message="Your business workspace is not connected yet.",
        )

    if not dashboard_response:
        return OnboardingState(
            welcome_seen=True,
            business_id_valid=True,
            backend_reachable=False,
            has_business_profile=True,
            has_products=False,
            has_transactions=False,
            onboarding_complete=False,
            current_step="products",
            progress_value=0.50,
            error_message="We could not check your workspace yet.",
        )

    if not bool(dashboard_response.get("success")):
        return OnboardingState(
            welcome_seen=True,
            business_id_valid=True,
            backend_reachable=False,
            has_business_profile=True,
            has_products=False,
            has_transactions=False,
            onboarding_complete=False,
            current_step="products",
            progress_value=0.50,
            error_message=_extract_error_message(dashboard_response),
        )

    data = _ensure_mapping(dashboard_response.get("data"))
    has_products = _has_products(data)
    has_transactions = _has_transactions(data)

    if not has_products:
        current_step = "products"
        progress = 0.50
    elif not has_transactions:
        current_step = "first_transaction"
        progress = 0.75
    else:
        current_step = "dashboard"
        progress = 1.00

    return OnboardingState(
        welcome_seen=True,
        business_id_valid=True,
        backend_reachable=True,
        has_business_profile=True,
        has_products=has_products,
        has_transactions=has_transactions,
        onboarding_complete=has_products and has_transactions,
        current_step=current_step,
        progress_value=progress,
        error_message=None,
    )


def is_valid_uuid(value: str) -> bool:
    """Return True when value is a valid UUID string."""

    if not isinstance(value, str) or not value.strip():
        return False
    try:
        UUID(value.strip())
    except (ValueError, AttributeError, TypeError):
        return False
    return True


def current_step_label(step: str) -> str:
    """Return user-facing step label."""

    labels = {
        "welcome": "Welcome",
        "business_profile": "Business Profile",
        "products": "Products",
        "first_transaction": "First Transaction",
        "dashboard": "Dashboard",
    }
    return labels.get(step, "Welcome")


def _has_products(data: Mapping[str, Any]) -> bool:
    """Detect product availability from dashboard payload."""

    product_summary = _ensure_mapping(data.get("product_summary"))
    inventory_summary = _ensure_mapping(data.get("inventory_summary"))
    if _mapping_has_positive_value(product_summary, ("product", "active", "total", "count")):
        return True
    if _mapping_has_positive_value(inventory_summary, ("product", "stock", "item", "total", "count")):
        return True
    return _has_non_empty_records(data.get("top_products_by_revenue")) or _has_non_empty_records(
        data.get("top_products_by_quantity")
    )


def _has_transactions(data: Mapping[str, Any]) -> bool:
    """Detect transaction availability from dashboard payload."""

    sales_summary = _ensure_mapping(data.get("sales_summary"))
    if _mapping_has_positive_value(
        sales_summary,
        ("transaction", "revenue", "sales", "quantity", "order", "total"),
    ):
        return True
    return _list_has_positive_metric(data.get("top_products_by_revenue")) or _list_has_positive_metric(
        data.get("top_products_by_quantity")
    )


def _mapping_has_positive_value(mapping: Mapping[str, Any], keywords: tuple[str, ...]) -> bool:
    """Return True if mapping contains a positive numeric metric."""

    for key, value in mapping.items():
        normalized_key = str(key).lower()
        if any(keyword in normalized_key for keyword in keywords):
            number = _to_decimal(value)
            if number is not None and number > 0:
                return True
        if isinstance(value, Mapping) and _mapping_has_positive_value(value, keywords):
            return True
    return False


def _list_has_positive_metric(value: Any) -> bool:
    """Return True if a list contains a positive numeric metric."""

    if not isinstance(value, list):
        return False
    for item in value:
        if isinstance(item, Mapping):
            for metric_value in item.values():
                number = _to_decimal(metric_value)
                if number is not None and number > 0:
                    return True
    return False


def _has_non_empty_records(value: Any) -> bool:
    """Return True if value is a non-empty list."""

    return isinstance(value, list) and bool(value)


def _ensure_mapping(value: Any) -> dict[str, Any]:
    """Return value as dict when possible."""

    if isinstance(value, Mapping):
        return dict(value)
    return {}


def _to_decimal(value: Any) -> Decimal | None:
    """Convert value to Decimal."""

    if isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def _extract_error_message(response: Mapping[str, Any]) -> str:
    """Extract API error message without exposing technical details."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return "We could not load your business workspace. Please try again."
    return "We could not load your business workspace. Please try again."
