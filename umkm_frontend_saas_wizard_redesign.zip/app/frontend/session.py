"""
Frontend Session Helpers
========================

Session state helpers for the Streamlit SaaS frontend.

The frontend stores UI preferences locally, but business data remains owned by
FastAPI and the backend layers.
"""

from __future__ import annotations

from typing import Any, MutableMapping

from app.frontend.api_client import FrontendApiClient


DEFAULT_API_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_BUSINESS_ID = ""
DEFAULT_SESSION_ID = "default-session"
DEFAULT_LIMIT = 1000
DEFAULT_CURRENCY = "IDR"
DEFAULT_TIMEZONE = "Asia/Jakarta"
DEFAULT_LANGUAGE = "Bahasa Indonesia"


def ensure_frontend_session(session_state: MutableMapping[str, Any]) -> None:
    """Ensure required frontend session keys exist."""

    session_state.setdefault("api_base_url", DEFAULT_API_BASE_URL)
    session_state.setdefault("business_id", DEFAULT_BUSINESS_ID)
    session_state.setdefault("session_id", DEFAULT_SESSION_ID)
    session_state.setdefault("dashboard_limit", DEFAULT_LIMIT)
    session_state.setdefault("welcome_seen", False)
    session_state.setdefault("business_name", "")
    session_state.setdefault("owner_name", "")
    session_state.setdefault("business_type", "")
    session_state.setdefault("currency", DEFAULT_CURRENCY)
    session_state.setdefault("timezone", DEFAULT_TIMEZONE)
    session_state.setdefault("language", DEFAULT_LANGUAGE)


def get_api_client_from_session_state(
    session_state: MutableMapping[str, Any],
) -> FrontendApiClient:
    """Build API client from Streamlit session state."""

    ensure_frontend_session(session_state)
    return FrontendApiClient(api_base_url=str(session_state["api_base_url"]))


def get_business_preferences(session_state: MutableMapping[str, Any]) -> dict[str, str]:
    """Return user-facing business preferences."""

    ensure_frontend_session(session_state)
    return {
        "business_name": str(session_state.get("business_name", "")),
        "owner_name": str(session_state.get("owner_name", "")),
        "business_type": str(session_state.get("business_type", "")),
        "currency": str(session_state.get("currency", DEFAULT_CURRENCY)),
        "timezone": str(session_state.get("timezone", DEFAULT_TIMEZONE)),
        "language": str(session_state.get("language", DEFAULT_LANGUAGE)),
    }


def save_business_preferences(
    session_state: MutableMapping[str, Any],
    preferences: dict[str, str],
) -> None:
    """Save user-facing business preferences to session state."""

    ensure_frontend_session(session_state)
    allowed_keys = {
        "business_name",
        "owner_name",
        "business_type",
        "currency",
        "timezone",
        "language",
    }
    for key in allowed_keys:
        if key in preferences:
            session_state[key] = preferences[key]


def build_common_payload(
    session_state: MutableMapping[str, Any],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build common API payload from session state."""

    ensure_frontend_session(session_state)
    payload = {
        "business_id": str(session_state["business_id"]),
        "session_id": str(session_state["session_id"]),
    }
    if extra:
        payload.update(extra)
    return payload
