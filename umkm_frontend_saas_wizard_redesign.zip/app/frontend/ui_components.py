"""
Frontend UI Components
======================

Reusable Streamlit UI components for the SaaS onboarding experience.
"""

from __future__ import annotations

from typing import Any

from app.frontend.onboarding import OnboardingState, current_step_label


def render_hero(st: Any, *, eyebrow: str, title: str, description: str) -> None:
    """Render a polished hero block."""

    st.markdown(
        f"""
        <section class="umkm-page-hero">
          <p class="umkm-page-hero__eyebrow">{eyebrow}</p>
          <h1 class="umkm-page-hero__title">{title}</h1>
          <p class="umkm-page-hero__description">{description}</p>
        </section>
        """,
        unsafe_allow_html=True,
    )


def render_progress(st: Any, state: OnboardingState) -> None:
    """Render onboarding progress indicator."""

    step = current_step_label(state.current_step)
    st.progress(state.progress_value, text=f"{int(state.progress_value * 100)}% complete · {step}")


def render_locked_message(
    st: Any,
    *,
    title: str,
    message: str,
    state: OnboardingState,
    action_label: str,
    page_path: str,
) -> None:
    """Render a single-step locked state."""

    render_hero(st, eyebrow="Setup required", title=title, description=message)
    render_progress(st, state)
    if st.button(action_label, type="primary"):
        switch_page(st, page_path)


def render_success_panel(st: Any, *, title: str, message: str) -> None:
    """Render success panel."""

    st.success(title)
    st.caption(message)


def render_friendly_error(st: Any, message: str) -> None:
    """Render non-technical error message."""

    st.error(message)
    st.caption("Please check your connection or open Settings if the issue continues.")


def switch_page(st: Any, page_path: str) -> None:
    """Switch page when supported by Streamlit."""

    if hasattr(st, "switch_page"):
        st.switch_page(page_path)
    else:
        st.info("Please use the sidebar to continue.")


def render_key_value_table(st: Any, data: dict[str, Any]) -> None:
    """Render dictionary as a friendly table."""

    if not data:
        st.info("No data available yet.")
        return
    records = [{"Item": _humanize_key(str(key)), "Value": value} for key, value in data.items()]
    st.dataframe(records, use_container_width=True, hide_index=True)


def _humanize_key(value: str) -> str:
    """Convert technical key into readable label."""

    return value.replace("_", " ").replace("-", " ").title()
