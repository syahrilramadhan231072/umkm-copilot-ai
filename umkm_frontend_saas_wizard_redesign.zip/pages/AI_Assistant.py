"""AI Assistant page."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_message


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="AI Assistant", page_icon="🤖", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    st.session_state.setdefault("chat_messages", [])
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Preparing assistant..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))
    state = build_onboarding_state(business_id=business_id, welcome_seen=True, dashboard_response=response)
    render_sidebar(st, state, current_page="AI Assistant")
    if not state.onboarding_complete:
        render_locked_message(st, title="AI Assistant unlocks after setup", message="Complete setup first so the assistant has business context.", state=state, action_label="Continue Setup", page_path="app.py")
        return
    st.title("AI Assistant")
    st.caption("Try: Which product sells best? Which products should I restock? What should I promote this week?")
    for message in st.session_state["chat_messages"]:
        with st.chat_message(message["role"]):
            st.markdown(str(message["content"]))
    user_input = st.chat_input("Ask your business copilot...")
    if user_input:
        st.session_state["chat_messages"].append({"role": "user", "content": user_input})
        with st.spinner("Thinking..."):
            result = client.route(user_input=user_input, payload={"business_id": business_id, "session_id": str(st.session_state.get("session_id", "default-session")), "user_message": user_input})
        st.session_state["chat_messages"].append({"role": "assistant", "content": _assistant_text(result)})
        st.rerun()
    if st.button("Clear Chat"):
        st.session_state["chat_messages"] = []
        st.rerun()


def _assistant_text(response: Mapping[str, Any]) -> str:
    if not response.get("success"):
        return "I could not process that yet. Please try again."
    data = response.get("data")
    return f"Done. {data}" if data else "Done."


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
