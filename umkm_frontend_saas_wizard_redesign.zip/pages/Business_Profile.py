"""Business Profile onboarding step."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import (
    DEFAULT_LIMIT,
    ensure_frontend_session,
    get_api_client_from_session_state,
    get_business_preferences,
    save_business_preferences,
)
from app.frontend.ui_components import render_friendly_error, render_hero, render_progress, switch_page


def render_page() -> None:
    """Render business profile step."""

    st = _get_streamlit()
    st.set_page_config(page_title="Business Profile", page_icon="🏪", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    response = None
    if is_valid_uuid(business_id):
        client = get_api_client_from_session_state(st.session_state)
        with st.spinner("Checking profile status..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))

    state = build_onboarding_state(
        business_id=business_id,
        welcome_seen=bool(st.session_state.get("welcome_seen", True)),
        dashboard_response=response,
    )
    render_sidebar(st, state, current_page="Business Profile")

    render_hero(
        st,
        eyebrow="Step 1 of 3",
        title="Tell us about your business",
        description="Start with a simple business profile. This helps personalize the copilot experience.",
    )
    render_progress(st, state)

    prefs = get_business_preferences(st.session_state)
    with st.form("business_profile_form"):
        business_name = st.text_input("Business Name", value=prefs["business_name"])
        owner_name = st.text_input("Owner Name", value=prefs["owner_name"])
        business_type = st.text_input("Business Type", value=prefs["business_type"], placeholder="Food & Beverage, Retail, Services")
        currency = st.selectbox("Currency", ["IDR", "USD"], index=0 if prefs["currency"] == "IDR" else 1)
        timezone = st.selectbox("Timezone", ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"], index=0)
        language = st.selectbox("Language", ["Bahasa Indonesia", "English"], index=0)
        submitted = st.form_submit_button("Save and Continue", type="primary")

    if submitted:
        save_business_preferences(
            st.session_state,
            {
                "business_name": business_name,
                "owner_name": owner_name,
                "business_type": business_type,
                "currency": str(currency),
                "timezone": str(timezone),
                "language": str(language),
            },
        )
        if state.has_business_profile:
            st.success("Business profile is connected.")
            switch_page(st, "pages/Products.py")
        else:
            render_friendly_error(
                st,
                "Your business preferences were saved, but your business workspace is not connected yet.",
            )

    with st.expander("Advanced", expanded=False):
        st.caption("For administrators only.")
        business_workspace = st.text_input("Business Workspace Reference", value=business_id, type="password")
        if st.button("Connect Workspace"):
            st.session_state["business_id"] = business_workspace.strip()
            st.success("Workspace reference saved.")
            st.rerun()


def _get_streamlit() -> Any:
    """Import Streamlit lazily."""

    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
