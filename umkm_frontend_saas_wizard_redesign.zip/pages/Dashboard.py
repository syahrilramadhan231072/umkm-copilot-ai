"""Production dashboard page using one get_dashboard request."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_message, render_progress


def render_page(api_client: Any | None = None) -> None:
    """Render dashboard only after onboarding is complete."""

    st = _get_streamlit()
    st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))

    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Loading dashboard..."):
            response = client.get_dashboard(business_id, limit)
    state = build_onboarding_state(
        business_id=business_id,
        welcome_seen=bool(st.session_state.get("welcome_seen", True)),
        dashboard_response=response,
    )
    render_sidebar(st, state, current_page="Dashboard")

    if not state.onboarding_complete:
        render_locked_message(
            st,
            title="Dashboard unlocks after setup",
            message="Complete your business profile, products, and first sale to see meaningful analytics.",
            state=state,
            action_label="Continue Setup",
            page_path="app.py",
        )
        return

    if not response or not response.get("success"):
        st.error("We could not load your dashboard. Please try again.")
        return

    data = _ensure_mapping(response.get("data"))
    st.title("Business Dashboard")
    render_progress(st, state)
    _render_kpis(st, _list_of_dicts(data.get("kpi_cards")))
    _render_alerts(st, _list_of_dicts(data.get("alerts")))
    tabs = st.tabs(["Sales", "Inventory", "Products", "Customers", "Top Products"])
    with tabs[0]:
        _render_summary(st, "Sales Summary", _ensure_mapping(data.get("sales_summary")))
    with tabs[1]:
        _render_summary(st, "Inventory Summary", _ensure_mapping(data.get("inventory_summary")))
    with tabs[2]:
        _render_summary(st, "Product Summary", _ensure_mapping(data.get("product_summary")))
    with tabs[3]:
        _render_summary(st, "Customer Summary", _ensure_mapping(data.get("customer_summary")))
    with tabs[4]:
        col_one, col_two = st.columns(2)
        with col_one:
            _render_ranking(st, "Top Revenue Products", _list_of_dicts(data.get("top_products_by_revenue")))
        with col_two:
            _render_ranking(st, "Top Quantity Products", _list_of_dicts(data.get("top_products_by_quantity")))


def extract_dashboard_cards(response: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Extract KPI cards for compatibility tests."""

    if not response.get("success"):
        return []
    return _list_of_dicts(_ensure_mapping(response.get("data")).get("kpi_cards"))


def extract_alerts(response: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Extract alerts for compatibility tests."""

    if not response.get("success"):
        return []
    return _list_of_dicts(_ensure_mapping(response.get("data")).get("alerts"))


def get_error_message(response: Mapping[str, Any]) -> str:
    """Extract error message."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])
    return "Dashboard failed to load."


def build_dashboard_request(business_id: str, limit: int = DEFAULT_LIMIT) -> dict[str, Any]:
    """Build dashboard request."""

    if not is_valid_uuid(business_id):
        raise ValueError("business_id must be a valid UUID.")
    if limit <= 0:
        raise ValueError("limit must be positive.")
    return {"business_id": business_id, "limit": limit}


def _render_kpis(st: Any, cards: list[dict[str, Any]]) -> None:
    """Render KPI cards."""

    if not cards:
        st.info("No KPI yet.")
        return
    columns = st.columns(min(len(cards), 4))
    for index, card in enumerate(cards):
        with columns[index % len(columns)]:
            label = str(card.get("label") or card.get("title") or card.get("key") or "Metric")
            value = _format_value(card.get("value"), label)
            delta = card.get("delta") or card.get("change") or card.get("trend")
            st.metric(label, value, delta=str(delta) if delta is not None else None)


def _render_alerts(st: Any, alerts: list[dict[str, Any]]) -> None:
    """Render alerts."""

    if not alerts:
        return
    st.subheader("Alerts")
    for alert in alerts:
        message = str(alert.get("message") or alert.get("title") or alert)
        severity = str(alert.get("severity") or alert.get("type") or "info").lower()
        if severity in {"danger", "error", "critical", "high"}:
            st.error(message)
        elif severity in {"warning", "warn", "medium"}:
            st.warning(message)
        else:
            st.info(message)


def _render_summary(st: Any, title: str, summary: dict[str, Any]) -> None:
    """Render summary metrics and detail."""

    st.subheader(title)
    if not summary:
        st.info("No data available yet.")
        return
    scalar_items = [(str(k), v) for k, v in summary.items() if _is_scalar(v)]
    if scalar_items:
        columns = st.columns(min(len(scalar_items), 4))
        for index, (key, value) in enumerate(scalar_items):
            with columns[index % len(columns)]:
                st.metric(_humanize(key), _format_value(value, key))
    detail = [{"Item": _humanize(str(k)), "Value": v} for k, v in summary.items()]
    with st.expander("View details"):
        st.dataframe(detail, use_container_width=True, hide_index=True)


def _render_ranking(st: Any, title: str, records: list[dict[str, Any]]) -> None:
    """Render product ranking."""

    st.subheader(title)
    if not records:
        st.info("No product ranking yet.")
        return
    normalized = []
    for item in records:
        name = item.get("product_name") or item.get("name") or item.get("product") or "Product"
        value = item.get("revenue") or item.get("total_revenue") or item.get("quantity") or item.get("total_quantity") or item.get("value") or 0
        normalized.append({"Product": str(name), "Value": _to_float(value) or 0.0})
    st.dataframe(normalized, use_container_width=True, hide_index=True)
    try:
        import pandas as pd
        chart_data = pd.DataFrame(normalized).set_index("Product")
        st.bar_chart(chart_data, use_container_width=True)
    except Exception:
        return


def _ensure_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    return {}


def _list_of_dicts(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) if isinstance(item, Mapping) else {"value": item} for item in value]


def _is_scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool, Decimal))


def _format_value(value: Any, key: str) -> str:
    if value is None:
        return "-"
    number = _to_decimal(value)
    if number is not None:
        formatted = f"{int(number):,}".replace(",", ".") if number == number.to_integral() else f"{float(number):,.2f}"
        if any(word in key.lower() for word in ["revenue", "sales", "price", "cost", "amount", "value"]):
            return f"Rp{formatted}"
        return formatted
    return str(value)


def _to_decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def _to_float(value: Any) -> float | None:
    number = _to_decimal(value)
    return float(number) if number is not None else None


def _humanize(key: str) -> str:
    return key.replace("_", " ").replace("-", " ").title()


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
