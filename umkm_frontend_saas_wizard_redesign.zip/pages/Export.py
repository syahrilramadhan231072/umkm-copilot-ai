"""Export workspace."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_message


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="Export", page_icon="⬇️", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Checking report readiness..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))
    state = build_onboarding_state(business_id=business_id, welcome_seen=True, dashboard_response=response)
    render_sidebar(st, state, current_page="Export")
    if not state.onboarding_complete:
        render_locked_message(st, title="Reports unlock after setup", message="Complete setup first so reports are not empty.", state=state, action_label="Continue Setup", page_path="app.py")
        return
    st.title("Export Reports")
    export_type = st.selectbox("Report", ["dashboard", "sales_summary", "inventory_summary"])
    export_format = st.selectbox("Format", ["json", "csv"])
    if st.button("Generate Export", type="primary"):
        payload = {"business_id": business_id, "export_format": export_format, "limit": int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))}
        with st.spinner("Generating export..."):
            if export_type == "dashboard":
                result = client.export_dashboard(payload)
            elif export_type == "sales_summary":
                result = client.export_sales_summary(payload)
            else:
                result = client.export_inventory_summary(payload)
        _render_download(st, result, export_format)


def _render_download(st: Any, response: Mapping[str, Any], export_format: str) -> None:
    if not response.get("success"):
        st.error("Export failed. Please try again.")
        return
    data = response.get("data") if isinstance(response.get("data"), Mapping) else {}
    export_data = data.get("export") if isinstance(data, Mapping) else None
    export_file = export_data if isinstance(export_data, Mapping) else data
    st.success("Export ready.")
    st.download_button(
        "Download",
        data=str(export_file.get("content", "")),
        file_name=str(export_file.get("filename", f"export.{export_format}")),
        mime=str(export_file.get("content_type", "text/csv" if export_format == "csv" else "application/json")),
    )


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
