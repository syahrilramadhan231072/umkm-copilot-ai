"""First transaction onboarding step."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_friendly_error, render_hero, render_progress, switch_page


def render_page() -> None:
    """Render first transaction step."""

    st = _get_streamlit()
    st.set_page_config(page_title="First Transaction", page_icon="🧾", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    client = get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "default-session"))
    limit = int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT))
    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Checking transaction setup..."):
            response = client.get_dashboard(business_id, limit)
    state = build_onboarding_state(
        business_id=business_id,
        welcome_seen=bool(st.session_state.get("welcome_seen", True)),
        dashboard_response=response,
    )
    render_sidebar(st, state, current_page="First Transaction")

    render_hero(
        st,
        eyebrow="Step 3 of 3",
        title="Record your first sale",
        description="One sale unlocks useful analytics, alerts, and AI recommendations.",
    )
    render_progress(st, state)

    if not state.has_products:
        render_friendly_error(st, "Add at least one product before recording your first sale.")
        return

    if state.has_transactions:
        st.success("First transaction found. Your dashboard is ready.")
        if st.button("Open Dashboard", type="primary"):
            switch_page(st, "pages/Dashboard.py")
        return

    with st.form("first_transaction_form"):
        st.caption("Select product support is dependent on the product catalog endpoint. For now, administrators can enter a product reference in Advanced.")
        quantity = st.number_input("Quantity Sold", min_value=1, value=1, step=1)
        payment_method = st.selectbox("Payment Method", ["cash", "qris", "transfer", "credit_card", "other"])
        notes = st.text_area("Notes", value="First sale")
        with st.expander("Advanced", expanded=False):
            product_reference = st.text_input("Product Reference", type="password")
        submitted = st.form_submit_button("Record First Sale", type="primary")

    if submitted:
        if not product_reference.strip():
            st.warning("Product reference is required until product selection is available.")
            return
        payload = {
            "business_id": business_id,
            "product_id": product_reference.strip(),
            "quantity": int(quantity),
            "payment_method": str(payment_method),
            "status": "completed",
            "notes": notes,
            "session_id": session_id,
        }
        with st.spinner("Recording first sale..."):
            result = client.record_transaction(payload)
        if result.get("success"):
            st.success("First sale recorded. Your dashboard is now ready.")
            switch_page(st, "pages/Dashboard.py")
        else:
            st.error(_error_message(result))


def _error_message(response: Mapping[str, Any]) -> str:
    """Extract user-friendly error message."""

    error = response.get("error")
    if isinstance(error, Mapping) and error.get("message"):
        return str(error["message"])
    return "We could not record the sale. Please try again."


def _get_streamlit() -> Any:
    """Import Streamlit lazily."""

    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
