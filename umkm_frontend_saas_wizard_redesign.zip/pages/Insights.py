"""Insights workspace."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_key_value_table, render_locked_message


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="Insights", page_icon="💡", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "default-session"))
    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Checking insight readiness..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))
    state = build_onboarding_state(business_id=business_id, welcome_seen=True, dashboard_response=response)
    render_sidebar(st, state, current_page="Insights")
    if not state.has_transactions:
        render_locked_message(st, title="Insights unlock after sales", message="Record your first sale so insights can be based on real activity.", state=state, action_label="Record First Transaction", page_path="pages/First_Transaction.py")
        return
    st.title("Insights")
    tab_context, tab_review, tab_save = st.tabs(["Context", "Review", "Save Insight"])
    with tab_context:
        if st.button("Load Insight Context", type="primary"):
            with st.spinner("Loading context..."):
                result = client.get_insight_context({"business_id": business_id, "limit": 100, "session_id": session_id})
            _render_result(st, result)
    with tab_review:
        keyword = st.text_input("Search")
        if st.button("Review Insights"):
            with st.spinner("Reviewing insights..."):
                result = client.get_insight_review(business_id=business_id, keyword=keyword or None, limit=100)
            _render_result(st, result)
    with tab_save:
        with st.form("save_insight"):
            title = st.text_input("Title")
            category = st.text_input("Category", value="general")
            content = st.text_area("Content")
            submitted = st.form_submit_button("Save Insight")
        if submitted:
            with st.spinner("Saving insight..."):
                result = client.create_insight({"business_id": business_id, "insight_data": {"title": title, "insight_category": category, "content": content}, "session_id": session_id})
            _render_result(st, result)


def _render_result(st: Any, response: Mapping[str, Any]) -> None:
    if not response.get("success"):
        st.error("Request failed. Please try again.")
        return
    data = response.get("data")
    if isinstance(data, Mapping):
        render_key_value_table(st, dict(data))
    elif isinstance(data, list):
        st.dataframe(data, use_container_width=True, hide_index=True)
    else:
        st.success("Done.")


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
