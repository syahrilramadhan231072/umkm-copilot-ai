"""Marketing workspace."""

from __future__ import annotations

from typing import Any, Mapping

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_locked_message, render_key_value_table


def render_page(api_client: Any | None = None) -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="Marketing", page_icon="📣", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    client = api_client or get_api_client_from_session_state(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    session_id = str(st.session_state.get("session_id", "default-session"))
    response = None
    if is_valid_uuid(business_id):
        with st.spinner("Checking marketing readiness..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))
    state = build_onboarding_state(business_id=business_id, welcome_seen=True, dashboard_response=response)
    render_sidebar(st, state, current_page="Marketing")
    if not state.has_products:
        render_locked_message(st, title="Marketing unlocks after products", message="Add products first so recommendations are relevant.", state=state, action_label="Continue Setup", page_path="pages/Products.py")
        return
    st.title("Marketing")
    tab_context, tab_record, tab_history = st.tabs(["Product Context", "Save Campaign", "History"])
    with tab_context:
        with st.expander("Advanced", expanded=False):
            product_reference = st.text_input("Product Reference", type="password")
        if st.button("Build Marketing Context", type="primary"):
            if not product_reference.strip():
                st.warning("Product selection is not available yet. Use Advanced reference for now.")
            else:
                with st.spinner("Building context..."):
                    result = client.get_marketing_context({"product_id": product_reference.strip(), "business_id": business_id, "session_id": session_id})
                _render_result(st, result)
    with tab_record:
        with st.form("marketing_record"):
            platform = st.text_input("Platform", value="Instagram")
            campaign_name = st.text_input("Campaign Name")
            caption = st.text_area("Caption")
            submitted = st.form_submit_button("Save Campaign")
        if submitted:
            with st.spinner("Saving campaign..."):
                result = client.create_marketing_record({"business_id": business_id, "marketing_data": {"platform": platform, "caption": caption, "campaign_name": campaign_name}, "session_id": session_id})
            _render_result(st, result)
    with tab_history:
        if st.button("Load History"):
            with st.spinner("Loading history..."):
                result = client.get_marketing_history(business_id=business_id, limit=100)
            _render_result(st, result)


def _render_result(st: Any, response: Mapping[str, Any]) -> None:
    if not response.get("success"):
        st.error("Request failed. Please try again.")
        return
    data = response.get("data")
    if isinstance(data, Mapping):
        render_key_value_table(st, dict(data))
    elif isinstance(data, list):
        st.dataframe(data, use_container_width=True, hide_index=True)
    else:
        st.success("Done.")


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
