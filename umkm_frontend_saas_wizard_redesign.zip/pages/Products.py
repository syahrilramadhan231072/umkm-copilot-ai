"""Products onboarding step."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import DEFAULT_LIMIT, ensure_frontend_session, get_api_client_from_session_state
from app.frontend.ui_components import render_friendly_error, render_hero, render_progress, switch_page


def render_page() -> None:
    """Render product setup step."""

    st = _get_streamlit()
    st.set_page_config(page_title="Products", page_icon="📦", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)

    business_id = str(st.session_state.get("business_id", ""))
    response = None
    if is_valid_uuid(business_id):
        client = get_api_client_from_session_state(st.session_state)
        with st.spinner("Checking product setup..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", DEFAULT_LIMIT)))
    state = build_onboarding_state(
        business_id=business_id,
        welcome_seen=bool(st.session_state.get("welcome_seen", True)),
        dashboard_response=response,
    )
    render_sidebar(st, state, current_page="Products")

    render_hero(
        st,
        eyebrow="Step 2 of 3",
        title="Add your products",
        description="Products give the copilot context for sales, stock, marketing, and recommendations.",
    )
    render_progress(st, state)

    if not state.has_business_profile:
        render_friendly_error(st, "Connect your business profile before adding products.")
        return

    if state.has_products:
        st.success("Products found. You can continue to your first transaction.")
        if st.button("Continue to First Transaction", type="primary"):
            switch_page(st, "pages/First_Transaction.py")
        return

    st.info(
        "No products were found in your workspace yet. Product creation is managed by the backend product catalog. "
        "Once products are available, this step will unlock automatically."
    )
    with st.form("product_preview_form"):
        st.text_input("Product Name")
        st.number_input("Selling Price", min_value=0, value=0)
        st.number_input("Cost Price", min_value=0, value=0)
        st.number_input("Initial Stock", min_value=0, value=0)
        st.selectbox("Unit", ["pcs", "cup", "bottle", "pack", "kg", "gram", "liter"])
        st.text_input("Category")
        submitted = st.form_submit_button("Check Product Setup")
    if submitted:
        st.warning("We could not find saved products yet. Please make sure products are available in your workspace.")


def _get_streamlit() -> Any:
    """Import Streamlit lazily."""

    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
