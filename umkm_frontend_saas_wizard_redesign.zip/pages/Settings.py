"""Settings page with user settings and collapsed advanced developer settings."""

from __future__ import annotations

from typing import Any

from app.frontend.assets import load_custom_css
from app.frontend.navigation import render_sidebar
from app.frontend.onboarding import build_onboarding_state, is_valid_uuid
from app.frontend.session import ensure_frontend_session, get_api_client_from_session_state, get_business_preferences, save_business_preferences


def render_page() -> None:
    st = _get_streamlit()
    st.set_page_config(page_title="Settings", page_icon="⚙️", layout="wide")
    load_custom_css(st)
    ensure_frontend_session(st.session_state)
    business_id = str(st.session_state.get("business_id", ""))
    response = None
    if is_valid_uuid(business_id):
        client = get_api_client_from_session_state(st.session_state)
        with st.spinner("Checking workspace..."):
            response = client.get_dashboard(business_id, int(st.session_state.get("dashboard_limit", 1000)))
    state = build_onboarding_state(business_id=business_id, welcome_seen=bool(st.session_state.get("welcome_seen", True)), dashboard_response=response)
    render_sidebar(st, state, current_page="Settings")
    st.title("Settings")
    st.caption("Manage your business preferences.")
    prefs = get_business_preferences(st.session_state)
    with st.form("preferences"):
        business_name = st.text_input("Business Name", value=prefs["business_name"])
        currency = st.selectbox("Currency", ["IDR", "USD"], index=0 if prefs["currency"] == "IDR" else 1)
        timezone = st.selectbox("Timezone", ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura"], index=0)
        language = st.selectbox("Language", ["Bahasa Indonesia", "English"], index=0 if prefs["language"] == "Bahasa Indonesia" else 1)
        submitted = st.form_submit_button("Save Preferences", type="primary")
    if submitted:
        save_business_preferences(st.session_state, {"business_name": business_name, "currency": str(currency), "timezone": str(timezone), "language": str(language)})
        st.success("Preferences saved.")
    with st.expander("Advanced", expanded=False):
        st.caption("Administrator settings.")
        api_base_url = st.text_input("API Base URL", value=str(st.session_state.get("api_base_url", "http://127.0.0.1:8000")))
        workspace_reference = st.text_input("Workspace Reference", value=business_id, type="password")
        debug = st.checkbox("Show debug status", value=False)
        if st.button("Save Advanced Settings"):
            st.session_state["api_base_url"] = api_base_url.strip().rstrip("/")
            st.session_state["business_id"] = workspace_reference.strip()
            st.success("Advanced settings saved.")
        if st.button("Check Connection"):
            client = get_api_client_from_session_state(st.session_state)
            with st.spinner("Checking connection..."):
                result = client.health_check()
            if result.get("success"):
                st.success("Connection successful.")
            else:
                st.error("Connection failed.")
        if debug:
            st.caption(f"Onboarding step: {state.current_step}")
            st.caption(f"Progress: {int(state.progress_value * 100)}%")


def _get_streamlit() -> Any:
    import streamlit as st
    return st


if __name__ == "__main__":
    render_page()
