"""Transactions workspace."""

from __future__ import annotations

from pages.First_Transaction import render_page


if __name__ == "__main__":
    render_page()
