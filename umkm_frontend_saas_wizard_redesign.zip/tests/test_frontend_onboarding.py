"""Tests for frontend onboarding state."""

from __future__ import annotations

from app.frontend.onboarding import build_onboarding_state, is_valid_uuid

VALID_UUID = "11111111-1111-4111-8111-111111111111"


def test_welcome_is_first_step() -> None:
    state = build_onboarding_state(business_id="", welcome_seen=False)
    assert state.current_step == "welcome"
    assert state.onboarding_complete is False


def test_business_profile_step_after_welcome_without_workspace() -> None:
    state = build_onboarding_state(business_id="", welcome_seen=True)
    assert state.current_step == "business_profile"
    assert state.business_id_valid is False


def test_uuid_validation() -> None:
    assert is_valid_uuid(VALID_UUID) is True
    assert is_valid_uuid("not-a-uuid") is False


def test_dashboard_ready_after_products_and_transactions() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 1, "total_revenue": 10000},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        welcome_seen=True,
        dashboard_response=response,
    )
    assert state.has_products is True
    assert state.has_transactions is True
    assert state.onboarding_complete is True
    assert state.current_step == "dashboard"


def test_first_transaction_step_when_products_exist_without_sales() -> None:
    response = {
        "success": True,
        "data": {
            "product_summary": {"total_products": 2},
            "sales_summary": {"total_transactions": 0},
        },
        "error": None,
    }
    state = build_onboarding_state(
        business_id=VALID_UUID,
        welcome_seen=True,
        dashboard_response=response,
    )
    assert state.current_step == "first_transaction"
    assert state.has_products is True
    assert state.has_transactions is False
